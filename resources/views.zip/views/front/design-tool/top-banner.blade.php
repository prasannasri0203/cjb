<!--banner-->
    <div class="banner">
        <div class="item">
            <img class="desk-banner" src="{{ asset('/images/creation_banner_03.png')}}" title="slidepicture" alt="slidepicture">
            <!-- <img class="mob-banner" src="images/creation_banner_04.png" title="slidepicture" alt="slidepicture"> -->
            <div class="caption station_caption">
                <h2 class="wlcr">Welcome to the Creation Station!</h2>
                <p>Follow your simple steps below to create your own unique Products!</p>
                <img class="mob-banner" src="{{ asset('/images/mug.png')}}" title="slidepicture" alt="slidepicture">
            </div>
        </div>
    </div>
    <!--/.banner-->