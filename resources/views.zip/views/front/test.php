@extends('front.app')

@section('title', '')

@section('header_script')
    <!-- Header Script Start -->

    <!-- Header Script End -->
@endsection

@section('body_class', '')

@section('main_div_class', 'homepg_Cont home-banner home-tablet')

@section('content')

        <!--Page Content Start-->

        <!--Page Content End-->

@endsection

@section('footer_script')
    <!-- Footer Script Start -->
    
    <!-- Footer Script End -->
@endsection