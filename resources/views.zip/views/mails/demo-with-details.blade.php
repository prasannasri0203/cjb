<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="800" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#1596c8">
  <tr>
    <td valign="top" height="30"></td>
  </tr>
  <tr>
    <td valign="top"><table width="800" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" width="30"></td>
    <td valign="top"><table width="740" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
  <tr>
    <td valign="top"><img src="{{asset('assets/images/images_03.jpg')}}" width="740" height="9" style="display:block;margin:0;border:0"/></td>
  </tr>
  <tr>
    <td valign="top"><table width="740" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" width="15"></td>
    <td valign="top"><table width="701" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" height="6"></td>
  </tr>
  <tr>
    <td valign="top"><table width="701" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" align="left"><img src="{{asset('assets/images/images_07.jpg')}}" width="221" height="85" style="display:block;margin:0;border:0"/></td>
    <td valign="top"><table width="480" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" height="27"></td>
  </tr>
  <tr>
    <td valign="top"><table border="0" cellspacing="0" cellpadding="0" align="right">
  <tr>
    <td valign="top"><img src="{{asset('assets/images/images_10.jpg')}}" width="33" height="32" style="display:block;margin:0;border:0"/></td>
    <td valign="top" width="10"></td>
    <td valign="top"><img src="{{asset('assets/images/images_12.jpg')}}" width="33" height="33" style="display:block;margin:0;border:0"/></td>
    <td valign="top" width="10"></td>
    <td valign="top"><img src="{{asset('assets/images/images_14.jpg')}}" width="33" height="33" style="display:block;margin:0;border:0"/></td>
  </tr>
</table>
</td>
  </tr>
</table>
</td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td valign="top" height="19"></td>
  </tr>
  <tr>
    <td valign="top" width="700" height="1" bgcolor="#b0bec3"></td>
  </tr>
  <tr>
    <td valign="top" height="25"></td>
  </tr>
  <tr>
    <td valign="top"><table width="701" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" width="1"></td>
    <td valign="top"><table width="700" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:15px; line-height:12px;color:#0d7293; text-align:left; font-weight:bold;">Customer Login Details</td>
  </tr>
  <tr>
    <td valign="top" height="25"></td>
  </tr>
  <tr>
    <td valign="top"><table width="700" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top"><table width="151" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top"><img src="{{asset('assets/images/profile.jpg')}}" width="151" height="140" style="display:block;margin:0;border:0"/></td>
  </tr>
  <tr>
    <td valign="top" height="5"></td>
  </tr>
  <tr>
    <td valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; line-height:12px;color:#3a3a3a; text-align:center; font-weight:bold;"></td>
  </tr>
</table>
</td>
    <td valign="top" width="17"></td>
    <td valign="top"><table width="541" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top"><table width="541" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" width="52"></td>
    <td valign="top"></td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td valign="top"><table width="541" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="52" align="left" valign="top"></td>
    <td width="479" align="left" valign="top" style="border-left:5px solid #1596c8; border-right:5px solid #1596c8; background:#fff;"><table width="479" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" width="19"></td>
    <td valign="top"><table width="460" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
  <tr>
    <td valign="top" height="14"></td>
  </tr>
  <tr>
      <td valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; line-height:12px;color:#3a3a3a; text-align:left;">Hello {{ $demoName }}</td>
  </tr>
  <tr>
    <td valign="top" height="3"></td>
  </tr>
  <tr>
    <td valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; line-height:12px;color:#3a3a3a;" >&emsp; &emsp; &emsp; &emsp; "Use this email and password to Login our Website"<br/></td>
  </tr>
  <tr>
    <td valign="top" height="20"></td>
  </tr>
  <tr>
    <td valign="top"><table width="460" border="0" cellspacing="0" cellpadding="0" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; line-height:12px;color:#3a3a3a;">
  <tr>
    <td valign="top" width="157" align="right">Useremail</td>
    <td valign="top" width="17"></td>
    <td valign="top" width="1">:</td>
    <td valign="top" width="9"></td>
    <td valign="top" style="color:#2862c5; text-decoration:underline;">{{ $demoEmail }}</td>
  </tr>
  <tr>
     <td colspan="5" height="13"></td>
  </tr>
  <tr>
    <td valign="top" width="157" align="right">Password </td>
    <td valign="top" width="17"></td>
    <td valign="top" width="1">:</td>
    <td valign="top" width="9"></td>
    <td valign="top">{{ Crypt::decrypt($demoPassword) }}</td>
  </tr>
  <tr>
    <td colspan="5" height="13"></td>
  </tr>
 <!-- <tr>
    <td valign="top" width="157" align="right">For more details visit</td>
    <td valign="top" width="17"></td>
    <td valign="top" width="1">:</td>
    <td valign="top" width="9"></td>
    <td valign="top" style="color:#2862c5; text-decoration:underline;">colan portal site</td>
  </tr> -->

  <tr>
    <td colspan="5" height="13"></td>
  </tr>
  
</table>
</td>
  </tr>
  
</table></td>
  </tr>
</table>
</td>
  </tr>
</table>
</td>
  </tr>
 
  <tr>
    <td valign="top"><table width="541" border="0" cellspacing="0" cellpadding="0">
  <tr>
     <td valign="top" width="52"></td>
    <td valign="top"></td>
  </tr>
</table>
</td>
  </tr>
</table>

</td>
     
  </tr>
</table>
</td>
  </tr>
</table>
</td>
  </tr>
</table>
</td>
  </tr>
  
  
</table>
</td>
    <td valign="top" width="24"></td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td valign="top" height="10"></td>
  </tr>
  <tr>
    <td valign="top"><img src="{{asset('assets/images/images_24.jpg')}}" width="740" height="9" style="display:block;margin:0;border:0"/></td>
  </tr>
</table>
</td>
     <td valign="top" width="30"></td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td valign="top"><table width="800" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" height="14"></td>
  </tr>
  <tr>
    <td valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; line-height:12px; text-align:center; font-weight:bold; color:#ffffff;">Copyright © 2019 Cool JellyBean</td>
  </tr>
  <tr>
    <td valign="top" height="14"></td>
  </tr>
</table>
</td>
  </tr>
</table>

</body>
</html>
