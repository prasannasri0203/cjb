<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td valign="top"><table width="600" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
  <tr>
    <td width="15"></td>
    <td valign="top">
      <table width="585" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="15"></td>
  </tr>
  <tr>
    <td valign="top"><img src="{{ asset('images/logo.png') }}" width="200" height="58" style="display:block;margin:0;border:0;" align="left"/></td>
  </tr>
  <tr>
    <td height="11"></td>
  </tr>
</table>
</td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td valign="top">
      <table width="600" border="0" cellspacing="0" cellpadding="0" bgcolor="#33b0de">
  <tr>
    <td height="13"></td>
  </tr>
  <tr>
    <td valign="top"><table width="600" border="0" cellspacing="0" cellpadding="0" bgcolor="#33b0de">
  <tr>
    <td height="12"></td>
  </tr>
  <tr>
    <td valign="top">
      <table width="600" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="24"></td>
     <td valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:21px; color:#061115; text-align:left; line-height:21px;">Customer Login Details
     </td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td height="11"></td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td height="16"></td>
  </tr>
</table>
</td>
  </tr>

  <tr>
    <td valign="top"><table width="600" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
  <tr>
    <td width="24"></td>
    <td valign="top"><table width="576" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="11"></td>
  </tr>
  <tr>
    <td valign="top"><table width="576" border="0" cellspacing="0" cellpadding="0">
  <tr>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td height="8"></td>
  </tr>
  <tr>
    <td valign="top"><table width="576" border="0" cellspacing="0" cellpadding="0">
  <tr>
        <td width="118" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-weight:bold; font-size:14px; color:#000000; text-align:left; line-height:21px;"></td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td height="8"></td>
  </tr>
  <tr>
    <td valign="top"><table width="576" border="0" cellspacing="0" cellpadding="0">
  <tr>
   <td width="118" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-weight:bold; font-size:14px; color:#000000; text-align:left; line-height:21px;">User email: </td>
    <td width="5" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-weight:bold; font-size:14px; color:#000000; text-align:left; line-height:21px;">:</td>
    <td width="5"></td>
    <td valign="top" style="font-family:Arial, Helvetica, sans-serif;font-size:14px; color:#000000; line-height:21px; text-align:left;">{{ $demoEmail}}</td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td height="8"></td>
  </tr>
  <tr>
    <td valign="top"><table width="576" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="118" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-weight:bold; font-size:14px; color:#000000; text-align:left; line-height:21px;">Password</td>
    <td width="5" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-weight:bold; font-size:14px; color:#000000; text-align:left; line-height:21px;">:</td>
    <td width="5"></td>
    <td valign="top" style="font-family:Arial, Helvetica, sans-serif;font-size:14px; color:#000000; line-height:21px; text-align:left;">{{ $demoPassword}}</td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td height="8"></td>
  </tr>
  <tr>
    <td valign="top"><table width="576" border="0" cellspacing="0" cellpadding="0">
  <tr>
     <td width="118" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-weight:bold; font-size:14px; color:#000000; text-align:left; line-height:21px;"><a href="{{ route('login') }}">Click here to login</a></td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td height="10"></td>
  </tr>
</table>
</td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td height="20" bgcolor="#0e5c79"></td>
  </tr>
</table>


</body>
</html>
