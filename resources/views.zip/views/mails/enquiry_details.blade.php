<html>
<head></head>
<body>
<table valign="center" align="center" width="620" border="1" cellspacing="0" cellpadding="0">
    <tbody>
    <tr>
        <td style="text-align: center;background: #006e73;padding: 7px;">
            <h2 style="color: white;margin-top: 14px; ">Cooljellybean</h2>
        </td>
    </tr>
    <tr>
        <td>
            <table width="620" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                <tr>
                    <td width="50">&nbsp;</td>
                    <td width="520">
                        <table width="600" border="0" cellspacing="0" cellpadding="0">
                            <tbody>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                        
                            <tr>

                                <td>&nbsp;</td>
                                <h3 style="margin-left: 7px;margin-top: 13px;">Hi cooljellybean</h3>

                            </tr>
                          
                            <tr>
                                <td style="color:#424242;font-size: 17px;font-family:'Calibri';font-weight: 600;">
                                   <span style="padding-left: 47px;">
                                   please Click below for your enquiry details.
                                   </span>
                                </td>
                            </tr>
                            <tr>
                            </tr>
                            <tr>
                                <td height="25">&nbsp;</td>
                            </tr>
                            <tr>
                                <td style="text-align: left;">
                                    <span style="color:#008dd4;font-size: 18px;font-family:'Calibri';">
                                     <?php echo '<a style="margin-left: 255px;" href="'.$url.'">Enquiry Details</a>'; ?>

                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td height="25">&nbsp;</td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                    <td width="50">&nbsp;</td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr style="text-align: center; background-color: #006e73; color:white;height:43px;font-family:'Calibri';font-size: 14px;">
        <td>Copyright © {{ date("Y") }} All Rights Reserved. </td>
    </tr>
    </tbody>
</table>
</body>
</html>

