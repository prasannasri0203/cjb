<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\MerchandiseProduct;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\CartDetails;
use App\CartItemDetails;
use App\OrderDetails;
use App\OrderCustomerAddressDetails;
use App\OrderItem;
use App\Revenuesharing;
use App\DeliveryAndPacking;
use App\Product_variant;
use App\Product;
use App\Print_types;
use Carbon\Carbon;
use Auth;
use Mail;
use App\User;
use Session;
use Notification;
use Validator;
use Input;
use App\address_book;
use App\Notifications\MyEnquiryNotification;
use App\Notifications\MyOrderNotification;
use App\Notifications\MyFaultAndReturnsNotification;

class CartController extends Controller
{   
    use AuthenticatesUsers;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
    // public function checkoutPage(){

    //     return view('front/cart/checkout_loggedin');     
    // }
    // public function checkoutPageView(){
    //     return view('front/cart/checkout_pay_card');     
    // }
    public function cardPageView(){  
        $delivery = DeliveryAndPacking::where('type',1)->get(); 
        $packing = DeliveryAndPacking::where('type',2)->get();
        $delivery_id ='';
        $packing_id ='';
        $cartList= [];
    	$additional_charge= 0;
       
        if (Auth::check()) {
            if((Auth::user()->type == 2) || (Auth::user()->type == 1)){
                $user_id= Auth::user()->id;
                $cartData = CartDetails::where('customer_id',$user_id)->where('status',1)->with('cartItems','cartItems.cartProducts','cartItems.cartProducts.merchProductImage')->first();
                if($cartData != null){
                    $packing_id = $cartData->packing_id;
                    $delivery_id = $cartData->delivery_id;
                    foreach ($cartData->cartItems as $key => $value) {
                        $id = $value->merchandise_product_id;
                        $product_details = MerchandiseProduct::where('id', $id)->with('artistDetails','merchProductImage','variantDetails')->first();
                    	$products = Product::where('id',$product_details->product_id)->where('deleted_at',null)->first();
                    	$offset = count( $value->cartProducts->merchProductImage)-1;
                        $cartList[$id]['image'] = $value->cartProducts->merchProductImage[$offset]->image;
                        $cartList[$id]['id'] = $id;
                        $cartList[$id]['name'] = $value->cartProducts->merchandise_product_name;
                        $cartList[$id]['artist'] = $product_details->artistDetails->name;
                        $cartList[$id]['price'] = $value->cartProducts->product_price;
                        $cartList[$id]['quantity'] = $value->quantity;
                        $cartList[$id]['variant'] =$product_details->variantDetails->variant_name;
                        $cartList[$id]['shipping_price'] = $products->shipping_cost;
                    }
                	

                    $cartItemDetail = CartItemDetails::where('customer_id',$user_id)
                    ->where('status','<=',2)->where('cart_id',$cartData->id)->get();

                    session()->put('cartCount', count($cartItemDetail));
                }
                // if($cartData == null){

                // }
            }
        } else{
            $cartData = session()->get('cart');
        	if($cartData != null){
            	foreach ($cartData as $key => $value) {

                $product_details = MerchandiseProduct::where('id', $key)->where('id', $key)->with('variantDetails')->first();           
				$products = Product::where('id',$product_details->product_id)->where('deleted_at',null)->first();
                    $cartList[$key]['image'] = $value['photo'];
                    $cartList[$key]['id'] = $key;
                    $cartList[$key]['name'] = $value['name'];
                    $cartList[$key]['artist'] = $value['artist'];
                    $cartList[$key]['price'] = $value['price'];
                    $cartList[$key]['quantity'] = $value['quantity'];
                    $cartList[$key]['variant'] = $product_details->variantDetails->variant_name;
                    $cartList[$key]['shipping_price'] = $products->shipping_cost;
            	}
        	}
            $packing_id = session()->get('packing_id');
            $delivery_id  = session()->get('delivery_id');
            session()->put('cartCount', count((array) session('cart')));
        }
		$product_print_type = Product::where('id',$product_details->product_id)->where('deleted_at',null)->get();
    //dd($products);
        if($product_print_type[0]['approved_additional_type'])
        {
            $print_type = unserialize($product_print_type[0]['approved_additional_type']);
            $print_price = unserialize($product_print_type[0]['approved_additional_price']);
            $table_value = Print_types::whereIn('id', $print_type)->get('print_type_name'); 
        	//dd($print_price);
        	$additional_charge = array_sum($print_price);
        }
        else
        {
            $print_type='';
            $print_price=''; 
            $table_value = '';       
        }
        $cart_id = $cartData->id;
    
        $print_cost = $cartData->print_price;
        if(!$print_cost)
        {
            $print_cost = 0;    
        }
        //dd(count($cartList));
        return view('front/cart/cart_page_view',compact('delivery','packing','cartList','delivery_id','packing_id','print_type','print_price','table_value','cart_id','print_cost','additional_charge'));      
    }
    public function printTypeUpdate(Request $request)
    {

        $cart_id = $request->input('id');
        $print_value = $request->input('value');

        $cartDetails = CartDetails::find($cart_id);
        $cartDetails->print_price =  $request->input('value');
        $cartDetails->save(); 
        $cartDetails = CartDetails::find($cart_id); 

        //dd($cartDetails);
           
        return response()->json(['status' => 'success','message'=>'Print type updated Successfully']);
    }
    public function guestCheckoutPage(){        
        return view('front/cart/checkout_guest');     
    }
    public function customerCheckoutPage(){   
        $user_id= Auth::user()->id;

        // $delivery = DeliveryAndPacking::where('type',1)->get(); 
        $packing = DeliveryAndPacking::where('type',2)->get();
        // $delivery_id ='';
        $packing_id ='';

        $customerDetails = User::where('id',$user_id)->first(); 
        $customerAddress = OrderCustomerAddressDetails::where('customer_id',$user_id)->get();

        $sub_total = 0;
        if (Auth::check()) {
            if((Auth::user()->type == 2)||(Auth::user()->type == 1)){
                $user_id= Auth::user()->id;
                $cartData = CartDetails::where('customer_id',$user_id)->where('status',1)->with('cartItems','cartItems.cartProducts','cartItems.cartProducts.merchProductImage')->first();               
           		$packing_id = $cartData->packing_id;
                $shipping_price = $cartData->shipping_price;
               
                $cart_id = $cartData->id;
                foreach ($cartData->cartItems as $key => $value) {
                    // dd($value);
                    $id = $value->merchandise_product_id;
                    $product_details = MerchandiseProduct::where('id', $id)->with('artistDetails','merchProductImage')->first();
                	$products = Product::where('id',$product_details->product_id)->where('deleted_at',null)->first();
                    $cartList[$id]['image'] = $value->cartProducts->merchProductImage[0]->image;
                    $cartList[$id]['id'] = $id;
                    $cartList[$id]['name'] = $value->cartProducts->merchandise_product_name;
                    $cartList[$id]['artist'] = $product_details->artistDetails->name;
                    $cartList[$id]['price'] = $value->cartProducts->product_price;
                    $cartList[$id]['quantity'] = $value->quantity;
                    $cartList[$id]['shipping_price'] = $products->shipping_cost;
                    $sub_total = $sub_total+($value->quantity * $value->cartProducts->product_price);
                    
                }

                $cartItemDetail = CartItemDetails::where('customer_id',$user_id)
                ->where('status','<',2)->get();
                session()->put('cartCount', count($cartItemDetail));
                $cartData = session()->get('cartCount');
              
            }
        } else{
            $cartData = session()->get('cart');
            $shipping_price= 0;
        	$print_price = 0;
        	$additional_charge = 0;
           
            foreach ($cartData as $key => $value) {
                $product_details = MerchandiseProduct::where('id', $key)->first();
            	$products = Product::where('id',$product_details->product_id)->where('deleted_at',null)->first();             
                $cartList[$key]['image'] = $value['photo'];
                $cartList[$key]['id'] = $key;
                $cartList[$key]['name'] = $value['name'];
                $cartList[$key]['artist'] = $value['artist'];
                $cartList[$key]['price'] = $value['price'];
                $cartList[$key]['quantity'] = $value['quantity'];
                // $cartList[$key]['shipping_price'] = $value['shipping_price'];
                $sub_total = $sub_total + ($value['quantity'] * $value['price']);
                $shipping_price = $products->shipping_cost + $shipping_price;
            }
            $packing_id = session()->get('packing_id');
            // $delivery_id  = session()->get('delivery_id');
            session()->put('cartCount', count((array) session('cart')));
        }
    	if($products->print_price)
        {
        	$extra_cost = unserialize($products->approved_additional_price);
        //dd();
        	if($extra_cost)
            {
            	$print_price = array_sum($extra_cost);
            }
        	else
            {
            	$print_price =0;
            }
        	
        }
        
    	
        return view('front/cart/checkout_loggedin',compact('shipping_price','customerDetails','customerAddress','packing','packing_id','sub_total','cart_id','print_price'));         
    }

    public function addAddressLoggedCustomer(Request $request){
        $rules = array(
            'no' => 'required',
            'street_1'  => 'required',
            'street_2'  => 'required',
            'region' => 'required',
            'country'   => 'required',
            'zipcode'    => 'required',
            'contact_no'     => 'required|integer'
        );
        $validator = Validator::make(Input::all(), $rules);
        if ($validator->fails()) {
            $data = array(
                'status' => 'error',                
                'message'=>$validator->getMessageBag()->toArray()
            ); 
            return response()->json($data);  
        }
     
       
        $customerAddress = new OrderCustomerAddressDetails;
            $customerAddress->customer_id = Auth::user()->id;
            $customerAddress->no          =  $request->no;
            $customerAddress->street_1    =  $request->street_1;
            $customerAddress->street_2    =  $request->street_2;
            $customerAddress->region      =  $request->region;
            $customerAddress->country     =  $request->country;
            $customerAddress->zipcode     =  $request->zipcode;
            $customerAddress->is_primary  =  0;
            $customerAddress->contact_no  =  $request->contact_no;

        $customerAddress->save();

        $data = new address_book;
        // $data->fname     = $request->no;
        $data->address1  = $request->street_1;
        $data->address2  = $request->street_2;
        $data->type      = Auth::user()->type;
        $data->user_id   = Auth::user()->id;
        $data->city_name = $request->region;
        $data->pscode    = $request->zipcode;
        $data->country   = $request->country;
        $data->phone     = $request->contact_no;
        $data->primary   = 0;
        $data->save();
        
            $data = array(
                'status' => 'success',    
                'message'=>'Address added successfully!'
            ); 
        return response()->json($data);    

    }

    public function addGuestCustomerDetails(Request $request){
        $customerAddress = new OrderCustomerAddressDetails;
            $customerAddress->customer_id = Auth::user()->id;
            $customerAddress->first_name  =  $request->first_name;
            $customerAddress->last_name   =  $request->last_name;
            $customerAddress->email       =  $request->email ;
            $customerAddress->no          =  $request->no;
            $customerAddress->street_1    =  $request->street_1;
            $customerAddress->street_2    =  $request->street_2;
            $customerAddress->region      =  $request->region;
            $customerAddress->country     =  $request->country;
            $customerAddress->zipcode     =  $request->zipcode;
            $customerAddress->contact_no  =  $request->contact_no;

        $customerAddress->save();
        return response()->json(['status' => 'success','message'=>'Address added successfully!']);    

    }
    
    public function customerCheckout(Request $request){   
        
        $validator = \Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }

        $credentials = $this->credentials($request);    
        if (Auth::attempt($credentials)) {


            if(isset($_POST['remember']))
            {
                setcookie('email', $request['email'], time()+31556926);
                setcookie('password', $request['password'], time()+31556926);
            }
            else
            {
                if(isset($_COOKIE['email']) && isset($_COOKIE['password']))
                {   
                    setcookie ('email', "", time() - 31556926);
                    setcookie ('password', "", time() - 31556926);
                }
            }

            $user_type = Auth::user()->type; 

        } else{
            return response()->json(['status' => 'error','item_count' => count((array) session('cart')) ]);
        }

        if (Auth::check()) {
            if(Auth::user()->type == 2){
                $shipping_price =0;
                $user_id= Auth::user()->id;
                
                $todayTime = Carbon::now();
        
                $cartCheck = CartDetails::where('customer_id',$user_id)->where('status',1)->first();
                // dd($cartCheck);
                if($cartCheck == null){
                    $packing_id =  session()->get('packing_id') ? session()->get('packing_id') :"";
                    // $shipping_price = session()->get('shipping_price')? session()->get('shipping_price'):"";

                    $cartDetail = new CartDetails;
                        $cartDetail->customer_id = $user_id;
                        $cartDetail->created_time = $todayTime->format("Y-m-d");
                        $cartDetail->notes = $request->notes?$request->notes:"";
                        $cartDetail->packing_id = $packing_id?$packing_id:"";
                        // $cartDetails->shipping_price = $shipping_price?$shipping_price:"";
                        $cartDetail->status = 1;
            
                    $cartDetail->save();
                    $newCartId = $cartDetail->id;
                } else{
                    $newCartId = $cartCheck->id;
                }
                $cart = session()->get('cart');
                if(isset($cart)) {
                    
                    foreach ($cart as $key => $value) {
                        $cartItemCheck = CartItemDetails::where('merchandise_product_id',$key)
                        ->where('customer_id',$user_id)->where('cart_id',$newCartId)->where('status',1)->first();
                        $product_details = MerchandiseProduct::find($key);
                            
                            if($cartItemCheck == null){
                                $cartItemDetail = new CartItemDetails;
                                    $cartItemDetail->cart_id = $newCartId;
                                    $cartItemDetail->customer_id = $user_id;
                                    $cartItemDetail->merchandise_product_id = $key;
                                    $cartItemDetail->quantity = $value['quantity'];
                                    $cartItemDetail->placed_date = $todayTime->format("Y-m-d");
                                    $cartItemDetail->status = 1;
                                $cartItemDetail->save();
                            } else{
                                $cartItemCheck->quantity   = $cartItemCheck->quantity + $value['quantity'];
                                $cartItemCheck->update();
                            }
                            
                       
                        unset($cart[$key]);
                    }
                    $cartItemCheck = CartItemDetails::where('customer_id',$user_id)->where('cart_id',$newCartId)->where('status',1)->get();
                    foreach ($cartItemCheck as $key => $value) {
                        $product_details = MerchandiseProduct::find($value->merchandise_product_id);
                        $shipping_price = $value->shipping_price + $shipping_price;
                    }   
                    
                    $cartCheck->shipping_price   = $shipping_price;
                    $cartCheck->update();
                    // $newCartId = $cartCheck->id;
                    session()->put('cart', $cart);
                }

                $cartItemDetail = CartItemDetails::where('customer_id',$user_id)->where('cart_id',$newCartId)->where('status',1)->get();
                session()->put('cartCount', $cartItemDetail->count());
            }
        }


        return response()->json(['status' => 'success','item_count' => count((array) session('cart')) ]);
        
    }

    public function updateCartQty(Request $request){
        $delivery = DeliveryAndPacking::where('type',1)->get(); 
        $packing = DeliveryAndPacking::where('type',2)->get();
        $delivery_id ='';
        $packing_id ='';
        $sub_total =0;
        $product_details = MerchandiseProduct::find($request->product_id);
        if (Auth::check()) {
            if(Auth::user()->type == 2){
            	$product_varient = Product_variant::where('id',$product_details->product_variant_id )->first();            	
                if($product_varient->quantites>=$request->quantity){
                $flag  = $this->addCart($request->note,$request->product_id,$request->quantity,'without');
                $user_id= Auth::user()->id;
                $cartData = CartDetails::where('customer_id',$user_id)->where('status',1)->with('cartItems','cartItems.cartProducts','cartItems.cartProducts.merchProductImage')->first();
                if($cartData != null){
                    $packing_id = $cartData->packing_id;
                    $delivery_id = $cartData->shipping_price;
                    foreach ($cartData->cartItems as $key => $value) {
                        $id = $value->merchandise_product_id;
                        if($request->product_id == $id){
                            $item_wise = $value->cartProducts->product_price * $value->quantity;
                        }
                        $sub_total =$sub_total+($value->cartProducts->product_price * $value->quantity);
                    }

                    $cartItemDetail = CartItemDetails::where('customer_id',$user_id)
                    ->where('status','<=',2)->where('cart_id',$cartData->id)->get();

                    session()->put('cartCount', count($cartItemDetail));
                }
               }
            else
            {
            	 return response()->json(['status' => 'error','message'=>'Product quantity not avaliable!' ]);
            }
        }
        }else{
            $cart = session()->get('cart');

            if($cart != null) {
                if(isset($cart[$request->product_id]))
                {
                    $packing_id = session()->get('packing_id');
                    // $delivery_id  = session()->get('delivery_id');
                    $product_varient = Product_variant::where('id',$product_details->product_variant_id )->first();            	
               		if($product_varient->quantites>=$request->quantity){
                    	foreach ($cart as $key => $value) {
                        	if ($key == $request->product_id) {
                            	$cart[$request->product_id]['quantity'] = $request->quantity;
                        	}
                    	}
                    }
                	else{
                    	return response()->json(['status' => 'error','message'=>'Product quantity not avaliable!' ]);
                    }
                    
                    session()->flash('message', 'Cart updated successfully');
                    session()->flash('message-type', 'success');
                    session()->put('cart', $cart);
                    foreach ($cart as $key => $value) {
                        if ($key == $request->product_id) {
                            $item_wise = $value['price'] * $value['quantity'];
                        }
                        $sub_total =$sub_total+($value['price'] * $value['quantity']);
                    }

                }
                
                session()->put('cartCount', count((array) session('cart')));
            }
        }
        $data['product_id'] = $request->product_id;
        $data['sub_total'] = $sub_total;
        $data['item_wise'] = $item_wise;
       

        return response()->json(['status' => 'success','message'=>'Product Update to cart successfully!','data'=>$data ]);    
 
    }

    public function cartItemRemove(Request $request){

        $sub_total = 0;
        if($request->product_id) {

            if (Auth::check()) {
                if(Auth::user()->type == 2){
                    $user_id= Auth::user()->id;
                    $cartCheck = CartDetails::where('customer_id',$user_id)->where('status','<',3)->first();
                	$find_quantity=CartItemDetails::where('cart_id',$cartCheck->id)->where('customer_id',$user_id)->where('merchandise_product_id',$request->product_id)->first();
                	$update_quantity=$find_quantity->quantity;
                    $product_details = MerchandiseProduct::where('id', $request->product_id)->first();   
                    $product_quantity= Product_variant::where('id',$product_details->product_variant_id)->where('status',1)->first();
                    $actual_quantity=$product_quantity->quantites;
                    $product_quantity->quantites   = $actual_quantity+$update_quantity;
                	$product_quantity->update();
                    $remove_data = CartItemDetails::where('cart_id',$cartCheck->id)->where('customer_id',$user_id)->where('merchandise_product_id',$request->product_id)->delete();

                    $user_id= Auth::user()->id;
                    $cartData = CartDetails::where('customer_id',$user_id)->where('status',1)->with('cartItems','cartItems.cartProducts','cartItems.cartProducts.merchProductImage')->first();
                    if($cartData != null){
                        $packing_id = $cartData->packing_id;
                        $delivery_id = $cartData->shipping_price;
                        foreach ($cartData->cartItems as $key => $value) {
                            $sub_total =$sub_total+($value->cartProducts->product_price * $value->quantity);
                        }

                        $cartItemDetail = CartItemDetails::where('customer_id',$user_id)
                        ->where('deleted_at',Null)->where('status',1)->where('cart_id',$cartData->id)->get();

                        session()->put('cartCount', count($cartItemDetail));
                    	$item_count =  count($cartItemDetail);
                    }
                }
    
            } else{
 
                $cart = session()->get('cart');    
                if(isset($cart[$request->product_id])) {
                 foreach ($cart as $key => $value) {                
    				$product_details = MerchandiseProduct::where('id', $request->product_id)->first();   
                    $product_quantity= Product_variant::where('id',$product_details->product_variant_id)->where('status',1)->first();
                    $actual_quantity=$product_quantity->quantites;
                    $product_quantity->quantites   = $actual_quantity+$value['quantity'];
                	$product_quantity->update();
                }
                    unset($cart[$request->product_id]);
                    session()->put('cart', $cart);
                 
                }
                $cart = session()->get('cart');
           
                $packing_id = session()->get('packing_id');
                $delivery_id  = session()->get('delivery_id');
                foreach ($cart as $key => $value) {
                    
                    $sub_total =$sub_total+($value['price'] * $value['quantity']);
                }
            $item_count = count((array) session('cart'));
                session()->put('cartCount', count((array) session('cart')));
                session()->flash('success', 'Product removed successfully');
            }
            $data['sub_total'] = $sub_total;
           
            return response()->json(['status' => 'success','message'=>'Product removed successfully','item_count' => $item_count,'data'=>$data ]); 
        }
    }

    public function addToCart(Request $request){

        $product_details = MerchandiseProduct::where('id', $request->product_id)->with('artistDetails','merchProductImage')->first();   
 		$product_quantity= Product_variant::where('id',$product_details->product_variant_id)->where('status',1)->first();
        $flag=0;
        
        if (Auth::check()) {
            if((Auth::user()->type == 2)||(Auth::user()->type == 1)){
            if(!$product_quantity)
            {
            	$flag=0;
            }
            else
            {
            	$flag  = $this->addCart($request->note,$request->product_id,1,'with');
            }
            }
            else{
                return response()->json(['status' => 'auth','message'=>'Artist cant add','item_count' => 0 ]);
            }
        //dd($flag);
        } else{
            $cart = session()->get('cart');
            if(!$cart) {
                $quantity=$product_quantity->quantites;
                if($quantity >=1){
               		 $cart[$request->product_id] = [
                    
                        "name"      => $product_details->merchandise_product_name,
                        "quantity"  => 1,
                        "price"     => $product_details->product_price,
                        "photo"     => $product_details->merchProductImage[0]->image,
                        "artist"    => $product_details->artistDetails->name,
                        // "delivery"  => 0
                        // "shipping_price"    =>$product_details->shipping_price
               		 ];
                               
                session()->put('cart', $cart);
            	// $product_quantity->quantites   = $quantity-1;
              	// $product_quantity->update();
                $flag=1;
                }
    
            } else {
    			
                if(isset($cart[$request->product_id]))
                {
                	$quantity=$product_quantity->quantites;
               		if($quantity >=1){
                   		 foreach ($cart as $key => $value) {
                        	if ($key == $request->product_id) {
                            	$cart[$request->product_id]['quantity']++;
                        	}
                    	}
                    	session()->put('cart', $cart);
    					// $product_quantity->quantites   = $quantity-1;
              			// $product_quantity->update();
                    $flag=1;
                	}
                } else{               			
                		$quantity=$product_quantity->quantites;
                		if($quantity >=1){
                        	$cart[$request->product_id] = [
                        		"name"      => $product_details->merchandise_product_name,
                        		"quantity"  => 1,
                        		"price"     => $product_details->product_price,
                        		"photo"     => $product_details->merchProductImage[0]->image,
                                "artist"    => $product_details->artistDetails->name,
                                // "shipping_price"    => $product_details->shipping_price
                                   
                    		];
                    		session()->put('cart', $cart);
                       	    // $product_quantity->quantites   = $quantity-1;
                    		// $product_quantity->update();
                        	$flag=1;
               			}
                }
                
            }
            session()->put('cartCount', count((array) session('cart')));
        }
        
        $cartData = session()->get('cartCount');
        // dd($flag);
    	if(($flag != 0)&&($product_quantity->quantites > 0)){
        	return response()->json(['status' => 'success','message'=>'Product added to cart successfully!','item_count' => $cartData ]); 
        }
    	else{
    		return response()->json(['status' => 'error','message'=>'Out of Stock!','item_count' => 0 ]);
        }
    }

    public function deliveryUpdate(Request $request){ 
        if (Auth::check()) {
            if(Auth::user()->type == 2){
                $user_id= Auth::user()->id;
                $cartCheck = CartDetails::where('customer_id',$user_id)->where('status',1)->with('cartItems','cartItems.cartProducts','cartItems.cartProducts.merchProductImage')->first();
                
                if($cartCheck == null){

                    $cartDetail = new CartDetails;
                        $cartDetail->customer_id = $user_id;
                        $cartDetail->created_time = $todayTime->format("Y-m-d");
                        $cartDetail->notes = "";
                        $cartDetail->delivery_id = $request->id;
                        $cartDetail->status = 1;
                    $cartDetail->save();
                } else{
                    $cartCheck->delivery_id   = $request->id;
                    $cartCheck->update();
                }

            }
        } else{
            session()->put('delivery_id', $request->id);
        }
        return response()->json(['status' => 'success','message'=>'Delivery Update Successfully']);
    }
    public function packingUpdate(Request $request){ 
        if (Auth::check()) {
            if((Auth::user()->type == 2)||(Auth::user()->type == 1)){
                $user_id= Auth::user()->id;
                $cartCheck = CartDetails::where('customer_id',$user_id)->where('status',1)->with('cartItems','cartItems.cartProducts','cartItems.cartProducts.merchProductImage')->first();
                
                if($cartCheck == null){

                    $cartDetail = new CartDetails;
                        $cartDetail->customer_id = $user_id;
                        $cartDetail->created_time = $todayTime->format("Y-m-d");
                        $cartDetail->notes = "";
                        $cartDetail->packing_id = $request->id;
                        $cartDetail->status = 1;
                    $cartDetail->save();
                } else{
                    $cartCheck->packing_id   = $request->id;
                    $cartCheck->update();
                }
            }
        } else{
            session()->put('packing_id', $request->id);
        }
        return response()->json(['status' => 'success','message'=>'Packing Update Successfully']);
    }

    public function customerOrder(Request $request){ 
        if((Auth::user()->type == 2)||(Auth::user()->type == 1)){
            if (Auth::check()) {
                $user_id= Auth::user()->id;
                $order_ref      = $this->orderRefNumber();
                $todayTime = Carbon::now();

                $cartCheck = CartDetails::where('id',$request->cart_id)->first();
                $cartCheck->completed_time   =  $todayTime->format("Y-m-d");
                $cartCheck->status   = 3;
                $cartCheck->update();

                $cartItemCheck = CartItemDetails::where('cart_id',$request->cart_id)->get();
                foreach ($cartItemCheck as $key => $value) {
                    $value->status  = 2;
                    $value->update();
                    $product_details = MerchandiseProduct::where('id', $value->merchandise_product_id)->first();
                    $artist_ids[] = $product_details->artist_id;
                }
                $artist_id = implode(',',$artist_ids);
                
                // $delivery = DeliveryAndPacking::where('type',1)->where('id',$cartCheck->delivery_id)->first(); 
                $packing = DeliveryAndPacking::where('type',2)->where('id',$cartCheck->packing_id)->first();
                $revenueColl = Revenuesharing::get();
                // dd($revenueColl);
                    foreach ($revenueColl as $key => $revenue) {
                        if($revenue->setting_key == 'artist-default-commission'){
                            $artist_revenue = $revenue->setting_value/100;
                            $artist_percent = $revenue->setting_value;
                        }
                        if($revenue->setting_key == 'affiliate-default-commission'){
                            $affiliate_revenue = $revenue->setting_value/100;
                            $affiliate_percent = $revenue->setting_value;
                        }
                        if($revenue->setting_key == 'admin-default-commission'){
                            $admin_revenue = $revenue->setting_value/100;
                            $admin_percent = $revenue->setting_value;
                        }
                    }

                

                $orderDetails= new OrderDetails;
                    $orderDetails->cart_id = $request->cart_id;
                    $orderDetails->order_id = $order_ref;
                    $orderDetails->customer_id = $user_id;
                    $orderDetails->order_ref_number = 1;
                    $orderDetails->billing_address_id = $request->billing_address;
                    $orderDetails->shipping_address_id = $request->billing_address;
                    $orderDetails->payment_type = 1;
                    $orderDetails->shipping_item_count = session()->get('cartCount');
                    $orderDetails->packing_name = $packing->delivery_name;
                    $orderDetails->packing_amount = $packing->delivery_value;
                    // $orderDetails->delivery_name = $delivery->delivery_name;                    
                    $orderDetails->delivery_amount = $cartCheck->shipping_price;
                    $orderDetails->sub_total = $request->sub_total;
                    $orderDetails->tax_total = 0;
                    $orderDetails->discount_total = 0;
                    $orderDetails->shipping_total = 0;
                    $orderDetails->grand_total = $request->grand_total;
                    $orderDetails->artist_revenue = $artist_revenue*$request->sub_total;
                    $orderDetails->affiliate_revenue = $affiliate_revenue*$request->sub_total;
                    $orderDetails->admin_revenue = $admin_revenue*$request->sub_total;
                    $orderDetails->artist_percent = $artist_percent;
                    $orderDetails->affiliate_percent = $affiliate_percent;
                    $orderDetails->admin_percent = $admin_percent;
                    $orderDetails->artist_id = $artist_id;
                    $orderDetails->affiliate_id = 0;
                    $orderDetails->notes = $request->notes? $request->notes:"";
                    $orderDetails->status = 1;
                $orderDetails->save();
                  
                $newOrderId = $orderDetails->id;
                // $newOrderId = 11;
                if($newOrderId){
                    $cartData = CartDetails::where('customer_id',$user_id)->where('id',$request->cart_id)->with('cartItems','cartItems.cartProducts','cartItems.cartProducts.merchProductImage')->first();

                    foreach ($cartData->cartItems as $key => $value) {
                        $id = $value->merchandise_product_id;
                        $product_details = MerchandiseProduct::where('id', $id)->with('ProductDetails.supplierName')->first();

                        $orderItemDetails= new OrderItem;
                            $orderItemDetails->order_id = $newOrderId;
                            $orderItemDetails->merchandise_product_id = $id;
                            $orderItemDetails->supplier_id = $product_details->ProductDetails->supplierName->id;
                            $orderItemDetails->product_price = $value->cartProducts->product_price;
                            $orderItemDetails->product_quantity = $value->quantity;
                            $orderItemDetails->status = 1;
                    		$orderItemDetails->customer_id = $user_id;
                        $orderItemDetails->save();
                    }
                        
                }
                    // $order_ref = '#ORDER20200000011';
                $cart_details['grand_total'] = $request->grand_total;
                $cart_details['order_number'] = $order_ref;
                $cart_details['qty'] = session()->get('cartCount');

                session()->put('cart_details', $cart_details);
                session()->put('cartCount',0);
                $content = [];
                $itemData =[];
                // Email data
                $orderDetails = OrderDetails::where('order_id',$order_ref)->with('orderItemDetails','customerBillingAddress','orderItemDetails.orderProducts','customerDetails')->first();
               
                foreach ($orderDetails->orderItemDetails as $key => $value) {
                    $item =[];
                    $item['id'] = $value->merchandise_product_id;
                    $item['name'] = $value->orderProducts->merchandise_product_name;
                    $item['image'] = $value->orderProducts->image;
                    $item['price'] = $value->product_price;
                    $item['product_quantity'] = $value->product_quantity;
                    $itemData[] = $item;
                }
                
                    $address['no'] = $orderDetails->customerBillingAddress->no;
                    $address['street_1'] = $orderDetails->customerBillingAddress->street_1;
                    $address['street_2'] = $orderDetails->customerBillingAddress->street_2;
                    $address['region'] = $orderDetails->customerBillingAddress->region;
                    $address['country'] = $orderDetails->customerBillingAddress->country;
                    $address['zipcode'] = $orderDetails->customerBillingAddress->zipcode;
                    $address['contact_no'] = $orderDetails->customerBillingAddress->contact_no;
                    $address['landmark'] = $orderDetails->customerBillingAddress->landmark;
                    $addressData[] = $address;
              
                
                $content['order_id'] = $orderDetails->id; 
                $content['order_ref'] = $orderDetails->order_id;                
                $content['name'] = Auth::user()->name;   
                $content['email'] = Auth::user()->email;   
                $content['sub_total'] =  $orderDetails->sub_total;  
                $content['tax_total'] = $orderDetails->tax_total;   
                $content['grand_total'] = $orderDetails->grand_total;   
                $content['payment_type'] = $orderDetails->payment_type;  
                $content['packing_name'] = $orderDetails->packing_name;   
                $content['packing_amount'] = $orderDetails->packing_amount;
                $content['delivery_name'] = $orderDetails->delivery_name;        
                $content['delivery_amount'] = $orderDetails->delivery_amount;    
                $content['order_items'] = $itemData;   
                $content['address'] = $addressData; 
                
                //notification
                
                $user = User::where('type', '0')->get();
                if($user){
                    $details =[
                        'id'  => $orderItemDetails->id,
                        'url' => 'admin/order_view/'.$orderItemDetails->id,
                    ];
                Notification::send($user, new MyOrderNotification($details));
                } 
                try{
                    
                    Mail::send('mails/order_mail', $content, function($message) use ($content) {
                        $message->to($content['email'])->subject('Cool Jelly Bean : New Order '.$content['order_ref']);
                        $message->from('xyz@gmail.com');
                        $message->setBody('test');
    
                    });
                    
                    if($request->payment_type == 'stripe'){
                        return redirect()->route('stripe_page');
                    } else {
                        return redirect()->route('paypal_page');
                    }
                    
                } catch(\Exception $e){
                    return $e;
                }

                $cartDetails = CartDetails::where('customer_id',$user_id)->where('id',$request->cart_id)->with('cartItems','cartItems.cartProducts','cartItems.cartProducts.ProductDetails','cartItems.cartProducts.ProductDetails.supplierName')->first();
                dd($cartDetails->cartItems);
                $contents['email'] = $cartDetails->email; 
                try{
                    
                    Mail::send('mails/order_mail', $content, function($message) use ($content) {
                        $message->to($contents['email'])->subject('Cool Jelly Bean : New Order '.$content['order_ref']);
                        $message->from('xyz@gmail.com');
                        $message->setBody('test');
                        $message->attach($pic);
    
                    });
                    
                    if($request->payment_type == 'stripe'){
                        return redirect()->route('stripe_page');
                    } else {
                        return redirect()->route('paypal_page');
                    }
                    
                } catch(\Exception $e){
                    return $e;
                }
            }
        } else{
            $this->guard()->logout();
            $request->session()->invalidate();
            return $this->loggedOut($request);
        }
    }

    public function termsConditionView(Request $request){
        return view('front/terms');     
    }
    public function policyView(Request $request){
        return view('front/policy');     
    }
    
    public function orderRefNumber()
    {       
        $returnId = OrderDetails::orderBy('id', 'DESC')->first();
        if($returnId == null)
        {
            $returnNo = '#ORDER'.date("Y").sprintf("%07d", (1));
        }
        else
        {
            $returnNo = '#ORDER'.date("Y").sprintf("%07d", ($returnId->id)+1);
        }
        return $returnNo;
    }

    public function addCart($notes,$product_id,$quantity,$with_value)
    { 
        $user_id= Auth::user()->id;
        $todayTime = Carbon::now();
        $flag =0;
        $shipping_price =0;
        // $cartCheck = CartDetails::where('customer_id',$user_id)->first();
        $cartCheck = CartDetails::where('customer_id',$user_id)->where('status',1)->with('cartItems','cartItems.cartProducts','cartItems.cartProducts.merchProductImage')->first();
       	$product_details = MerchandiseProduct::where('id',$product_id)->where('status',1)->first();
    	$product_quantity= Product_variant::where('id',$product_details->product_variant_id)->where('status',1)->first();
    	if($cartCheck == null){
            
            $cartDetail = new CartDetails;
            $cartDetail->customer_id = $user_id;
            $cartDetail->created_time = $todayTime->format("Y-m-d");
            $cartDetail->notes = $notes?$notes:"";
            $cartDetail->status = 1;
            
            $cartDetail->save();
            $newCartId = $cartDetail->id;
        } else{
            $newCartId = $cartCheck->id;
        }
        
        $cartItemCheck = CartItemDetails::where('merchandise_product_id',$product_id)
        ->where('customer_id',$user_id)->where('cart_id',$newCartId)->first();

        if($cartItemCheck == null){
        	$quantites=$product_quantity->quantites;
       		if($quantites >=1){
            	$cartItemDetail = new CartItemDetails;
                	$cartItemDetail->cart_id = $newCartId;
                	$cartItemDetail->customer_id = $user_id;
                	$cartItemDetail->merchandise_product_id = $product_id;
                	$cartItemDetail->quantity = 1;
                	$cartItemDetail->placed_date = $todayTime->format("Y-m-d");
                	$cartItemDetail->status = 1;
            	$cartItemDetail->save();
            	$product_quantity->quantites   = $quantites-1;
                   $product_quantity->update();
                   $flag =1;
            }
       	}else{
        	$quantites=$product_quantity->quantites;
       		if($quantites >=1){
            	if($with_value == 'with'){
                	$cartItemCheck->quantity  = $cartItemCheck->quantity + $quantity;
            	} else{
                	$cartItemCheck->quantity  = $quantity;
           		}
           		$cartItemCheck->update();
            	$product_quantity->quantites   = $quantites-$quantity;
                   $product_quantity->update();
                   $flag =1;
       	 	}
        }
        
        $cartItemDetail = CartItemDetails::where('cart_id',$newCartId)->where('customer_id',$user_id)
        ->where('status','<',2)->get();

        // $cartItemCheck = CartItemDetails::where('customer_id',$user_id)->where('cart_id',$newCartId)->where('status',1)->get();
        foreach ($cartItemDetail as $key => $value) {        
            $product_details = MerchandiseProduct::find($value->merchandise_product_id);
            $products = Product::where('id',$product_details->product_id)->where('deleted_at',null)->first(); 
            $shipping_price = $products->shipping_cost + $shipping_price;
        }   
        $cartCheck = CartDetails::where('customer_id',$user_id)->where('status',1)->first();
        $cartCheck->shipping_price   = $shipping_price;
        $cartCheck->update();

        session()->put('cartCount', count($cartItemDetail));

        return $flag;
    }  
	public function additionalchargeUpdate(Request $request)
    {
    	//dd($request->all());
    
 		CartDetails::where('id', $request->id)
       ->update([
           'print_price' => $request->charge
        ]);  
 
             $data = array(
                'status' => 'true',                
            ); 
            return response()->json($data); 
    }

}
