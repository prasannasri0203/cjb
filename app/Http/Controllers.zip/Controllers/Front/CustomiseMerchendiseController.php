<?php

namespace App\Http\Controllers\front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\ArtistCategory;
use App\MerchandiseProduct;
use App\MerchandiseProductImages;
use DB;
use Auth;
use App\Product;
use App\Product_variant;
use App\ArtistMerchandiseProduct;

class CustomiseMerchendiseController extends Controller
{
    public function merchendiseView(){  
       $user_id=  Auth::user()->id;
        $category_lists = DB::table('merchandise_products AS a')
        ->leftJoin('artist_category AS c', 'a.artist_category_id', '=', 'c.id')
        ->leftJoin('merchandise_product_images AS i', 'a.id', '=', 'i.merch_product_id')
        ->select('a.artist_category_id','a.id','i.image','c.category_name','a.merchandise_product_name','a.product_price')
        ->where('c.user_id',$user_id)
        ->where('a.status','1')
        ->where('a.deleted_at',null)
        ->orderBy('c.sort_order', 'ASC')     
        ->get();
        
        // $category_lists = ArtistMerchandiseProduct::with('AMProduct.product_category', 'AMProduct.ProductImages')
        //                         ->where('artist_merchandise_products.user_id', Auth::user()->id)
        //                         // ->where('products.status','1')
        //                         ->get();

        // dd($products);

        $category_id = 0;
        $category_list =[];

       $category_header= ArtistCategory::where('user_id',$user_id)->select('id','category_name')->get();
       $array_val = [];
        foreach ($category_lists as $key => $value) {
       if (!in_array($value->id, $array_val))
       {
             $array_val[] = $value->id;
           
            if($category_id == $value->artist_category_id){

                $category_id = $value->artist_category_id;
                $data[$key]['id'] = $value->artist_category_id;
                $data[$key]['product_id'] = $value->id;
                $data[$key]['image'] = $value->image; 
                $data[$key]['merchandise_product_name'] = $value->merchandise_product_name; 
                $data[$key]['product_price'] = $value->product_price; 
                $category_list[$value->category_name] =$data;           
            }else if($category_id != $value->artist_category_id){

                if($category_id == 0){
                    $category_id = $value->artist_category_id;
                    $data[$key]['id'] = $value->artist_category_id;
                    $data[$key]['product_id'] = $value->id;
                    $data[$key]['image'] = $value->image;
                    $data[$key]['merchandise_product_name'] = $value->merchandise_product_name; 
                    $data[$key]['product_price'] = $value->product_price;            
                    $category_list[$value->category_name] =$data;

                } else {
                    $data =[];
                    $category_id = $value->artist_category_id;

                    $data[$key]['id'] = $value->artist_category_id;
                    $data[$key]['product_id'] = $value->id;
                    $data[$key]['image'] = $value->image;
                    $data[$key]['merchandise_product_name'] = $value->merchandise_product_name; 
                    $data[$key]['product_price'] = $value->product_price;            
                    $category_list[$value->category_name] =$data;
                    
                }
            }
            
       }

        }
        //dd($category_list);
        // $category_list = MerchandiseProduct::with('artistCategoryName')->where('user_id',1)->get();
        return view('front/manage_merchandise_product',compact('category_list','category_header'));
    }

    public function artistMerchendiseSortUpdate(Request $request){
       
        $init = 1;
        $flag = [];
        foreach ($request->category_order as $key => $value) {
            $artistCategory = ArtistCategory::where('category_name',$value)->update(['sort_order'=> $init]);
            $init++;
            // if($artistCategory != null){
            //     $flag[] = 1;
            // } else{
            //     $flag[] = 0;
            // }
        }

        return response()->json(array('status' => true));
    }

    public function deleteImage($id,Request $request){
        MerchandiseProduct::where('id',$id)->delete();
        MerchandiseProductImages::where('merch_product_id',$id)->delete();
        return redirect('/manage_merchandise_product')->with('success','product deleted successfully.');
    }

    public function EditProductDetails($id){
        $value=[];
        $variants=[];
        $selected =[];
        $merch_table=MerchandiseProduct::where('id',$id)->where('deleted_at',null)->first();
        $product_varient=Product_variant::where('product_id',$merch_table->product_id)->where('deleted_at',null)->get();
        
        $selected_product_varient = Product_variant::where('id',$merch_table->product_variant_id)->first();
        
            $after_explode = explode(",",str_replace(array('"',']','['), '', $selected_product_varient->attributes));
            $selected['size'] =$after_explode[0];
            $selected['color'] =$after_explode[1];
         
            foreach($product_varient as $key => $value){  
              
                // $variants = explode(",",$value->attributes);
                $after_restring = str_replace(array('"','[',']'), '', $value->attributes);
                $variants[$value->id] = str_replace(',', '-', $after_restring);
                
            }
            // dd($variants);
 
        $value['merchandise_product_name']=$merch_table->merchandise_product_name;
        $value['product_price']=$merch_table->product_price;
        $value['artist_category_id']=$merch_table->artist_category_id;
        $value['variant']=$variants;
        $value['selected']=$selected;

        $data = array(
            'status' => 'success',
            'data'=>$value,
            'message'=>'Data updated successfully!'
        ); 
        return response()->json($data);
    }

    public function UpdateProductDetails(Request $request){     
        // dd($request->all());  
        $update_product=MerchandiseProduct::where('id',$request->id)->update([
            'merchandise_product_name' =>   $request->merchandise_product_name,
            'product_price'            =>   $request->product_price,
            'artist_category_id'       =>   $request->artist_category_id,
            'product_variant_id'       =>   $request->product_variant_id
        ]);
        $data = array(
            'status' => 'success',
            // 'data'=>$value,
            'message'=>'Data updated successfully!'
        ); 
        return response()->json($data);
        // return redirect('/manage_merchandise_product')->with('success','product updated successfully.');
    }
}
