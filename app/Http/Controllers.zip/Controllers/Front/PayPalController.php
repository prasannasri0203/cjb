<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Srmklive\PayPal\Services\ExpressCheckout;

class PayPalController extends Controller
{
     /**
     * Responds with a welcome message with instructions
     *
     * @return \Illuminate\Http\Response
     */
    public function payment()
    {
        $data = [];
        $cart_details  = session()->get('cart_details');
        $total = (int)$cart_details['grand_total'];
        $order_ref = $cart_details['order_number'];
        // $data['items'] = [
        //     [
        //         'name' => 'CoolJelly Bean',
        //         'price' => 100,
        //         'desc'  => 'testet',
        //         'qty' => 10,
        //         ]
        //     ];

        $data['items'] = [
                [
                    'name' => 'Cool Jelly Bean',
                    'price' => $total ,
                    'desc'  => 'Description for ItSolutionStuff.com',
                    'qty' => 1
                ]
            ]; 

        $data['invoice_id'] = $order_ref;
        $data['invoice_description'] = "Order {$data['invoice_id']} Invoice";
        $data['return_url'] = route('payment.success');
        $data['cancel_url'] = route('payment.cancel');
        $data['total'] = $total ;

        // $datas['invoice_id'] = 1;
        // $datas['invoice_description'] = "Order #{$datas['invoice_id']} Invoice";
        // $datas['return_url'] = route('payment.success');
        // $datas['cancel_url'] = route('payment.cancel');
        // $datas['total'] = 100;

        $provider = new ExpressCheckout;
        
        $response = $provider->setExpressCheckout($data);
        
        $response = $provider->setExpressCheckout($data, true);
        // dd($response);
  
        return redirect($response['paypal_link']);
    }

    public function paymentPage(Request $request)
    {   
        return view('front/paypal_page');
    }
   
    /**
     * Responds with a welcome message with instructions
     *
     * @return \Illuminate\Http\Response
     */
    public function cancel()
    {
        return redirect()->away('https://www.sandbox.paypal.com');
    }
  
    /**
     * Responds with a welcome message with instructions
     *
     * @return \Illuminate\Http\Response
     */
    public function success(Request $request)
    {
        $response = $provider->getExpressCheckoutDetails($request->token);
  
        if (in_array(strtoupper($response['ACK']), ['SUCCESS', 'SUCCESSWITHWARNING'])) {
            $responseJSON = json_encode($response);
  
                $orderDetails = OrderDetails::where('order_id',$cart_details['order_number'])->first();
                $orderDetails->status   = 2;
                $orderDetails->order_ref_number   = $response['txn_id'];
                $orderDetails->order_api_response   = $responseJSON;
                $orderDetails->update();

                session()->put('cartCount', 0);
            return view('front/cart/checkout_pay_card'); 
            // dd('Your payment was successfully. You can create success page here.');
        }
  
        dd('Something is wrong.');
    }
}
