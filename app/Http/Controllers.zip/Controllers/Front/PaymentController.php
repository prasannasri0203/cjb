<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Stripe\Stripe;
use Stripe\Charge;
use Validator;
use URL;
use Session;
use Redirect;
use Input;
use Auth;
use App\OrderDetails;
use App\User;
// use Stripe\Error\Card;
// use Cartalyst\Stripe\Stripe;

class PaymentController extends Controller
{
     // /**
    //  * success response method.
    //  *
    //  * @return \Illuminate\Http\Response
    //  */
    // public function stripe()
    // {
    //     return view('front/stripe_page');
    // }

    /**
     * Redirect the user to the Payment Gateway.
     *
     * @return Response
     */
    public function stripe(Request $request)
    {  
        $cart_details  = session()->get('cart_details');
        $order_number = $cart_details['order_number'];
        return view('front/stripe_page',compact('order_number'));
    }

    public function sampleOrder(Request $request)
    {   
        return view('mails/order_mail');
    }
    

    /**
 * Redirect the user to the Payment Gateway.
 *
 * @return Response
 */
public function payStripe(Request $request)
{
    $this->validate($request, [
        'card_no' => 'required',
        'expiry_month' => 'required',
        'expiry_year' => 'required',
        'ccv' => 'required',
    ]);
    $stripe = Stripe::setApiKey('sk_test_51GuxWGBgoBYViK1lQMEPEZJOd474kMgiJyWYlcSNkWBkgcMiuWC4X9hYO3gZDp163rLRXp0qjCP5favGD0nzKTUd00TZUXcLNX');
    // $stripe = Stripe::setApiKey('sk_test_51GuxWGBgoBYViK1lQMEPEZJOd474kMgiJyWYlcSNkWBkgcMiuWC4X9hYO3gZDp163rLRXp0qjCP5favGD0nzKTUd00TZUXcLNX');
    // $stripe = Stripe::make('sk_test_51GuxWGBgoBYViK1lQMEPEZJOd474kMgiJyWYlcSNkWBkgcMiuWC4X9hYO3gZDp163rLRXp0qjCP5favGD0nzKTUd00TZUXcLNX');
    // $stripe = Stripe::setApiKey(env('STRIPE_SECRET'));

    $stripe = new \Stripe\StripeClient(
        'sk_test_51GuxWGBgoBYViK1lQMEPEZJOd474kMgiJyWYlcSNkWBkgcMiuWC4X9hYO3gZDp163rLRXp0qjCP5favGD0nzKTUd00TZUXcLNX'
    );
    
    try {
        $token = $stripe->tokens->create([
            'card' => [
                'number'    => $request->get('card_no'),
                'exp_month' => $request->get('expiry_month'),
                'exp_year'  => $request->get('expiry_year'),
                'cvc'       => $request->get('ccv'),
            ],
        ]);

    
    if (!isset($token['id'])) {
        return Redirect::to('strips')->with('Token is not generate correct');
    }
    $cart_details  = session()->get('cart_details');

    $charge = Charge::create(array(
        'amount' => $cart_details['grand_total']*100,
        "source" => $token,
        'currency' => 'INR',
        'description' => $cart_details['order_number'],

    ));
    $responseJSON = json_encode($charge);
  
    $orderDetails = OrderDetails::where('order_id',$cart_details['order_number'])->first();
    $orderDetails->status   = 2;
    $orderDetails->order_ref_number   = $charge->id;
    $orderDetails->order_api_response   = $responseJSON;
    $orderDetails->update();

    session()->put('cartCount', 0);


     return view('front/cart/checkout_pay_card'); 
    } catch (\Exception $ex) {
        return $ex->getMessage();
    }
        
  }  
}
