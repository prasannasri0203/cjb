<?php

namespace App\Http\Controllers\Front;

use DB;
use App\User;
use App\Review;
use App\Product;
use App\Categories;
use App\Product_variant;
use App\Print_types;
use App\MerchandiseProduct;
use App\MerchandiseProductImages;
use Illuminate\Http\Request;
use Input;
use App\Http\Controllers\Controller;
use Image;
use File;

class ProductController extends Controller
{
    public function product_list()
    {
        // dd($id);
        $get_cat = Categories::where('parent_id',0)->whereNull('deleted_at')->get();
        $cat_id = Input::get('cat_id');
        if($cat_id){
            $category_id = Categories::whereNull('deleted_at')->where('id',$cat_id)->first();
        // dd($category_id);
            $product = MerchandiseProductImages::with(['merch_image','ProductDetails.ProductCategory']);
            if($cat_id){
                $product = $product->whereHas('ProductDetails.ProductCategory', function($q) use($category_id){
                    $q->where('category_name',$category_id->category_name);
                });
            }            
            $product = $product->paginate(6);

            $product_fill = MerchandiseProductImages::with(['merch_image','ProductDetails.ProductCategory']);
                $product_fill = $product_fill->whereHas('ProductDetails.ProductCategory',function($q) use($category_id){
                $q->where('category_name',$category_id->category_name);   
            });

            $product_fill = $product->first();
        }
            // dd($product_fill);
            $user = User::where('type',1)->get();
            $product_name = MerchandiseProduct::where('deleted_at',null)->get();
            $collection = collect($product_name);
            $unique_data = $collection->unique('merchandise_product_name')->values()->all();


            $product_data = DB::table('products')
                ->select('*')
                ->join('product_images', 'product_images.product_id', '=', 'products.id')
                ->where('products.category_id', $cat_id)
                ->paginate(10);
            //dd($product_data);


            return view('front/product_list',compact('product','unique_data','product_name','product_fill','user','get_cat','product_data'));
    
    }
    public function list(Request $request)
    {

        // dd($user);
        $product = MerchandiseProductImages::with(['merch_image','ProductDetails.ProductCategory']);
            if($request->merchandise_product_name){
                $product = $product->whereHas('ProductDetails.ProductCategory', function($q) use($request){
                    $q->where('category_name',$request->merchandise_product_name);
                });
            }
            if($request->artist_id){
                $product = $product->whereHas('merch_image',function($q) use($request){
                    $q->where('artist_id',$request->artist_id);
                });
            }
            if($request->product_value[0] == "1"){
                $product = $product->whereHas('merch_image',function($q) use($request){
                $q->orderBy('product_price','ASC');
                });
            }
            if($request->product_value[0] == "2"){
                $product = $product->whereHas('merch_image',function($q) use($request){
                $q->orderBy('product_price','DESC');
                });
            }
            if($request->product_value[0] == "0"){
                $product = $product->whereHas('merch_image',function($q) use($request){
                $q->orderBy('product_price','ASC')->latest();
                });
            }

        $product = $product->paginate(6);   
        // dd($product);
        $get_cat = Categories::where('parent_id',0)->whereNull('deleted_at')->get();
        $user = User::where('type',1)->get();
        $product_name = MerchandiseProduct::where('deleted_at',null)->get();    
        return view('front/merch_prod_list',compact('product','product_name','get_cat','user'));
    }


    public function detail_view($id)
    {
    	$review_rating=0;
        $total_review=0;
        $merch_product = MerchandiseProductImages::where('merch_product_id',$id)->first();
        $get_product = MerchandiseProductImages::where('merch_product_id',$id)->get();
        $get_product = $get_product->sortByDesc('sort');
        if(count($get_product) == 0){
            return redirect('product_detail/1');
        }       
        $merchproduct = MerchandiseProduct::where('id',$id)->first();
        $productdetails = Product::where('id',$merchproduct->product_id)->first();
        
        // $productList = Product::where('category_id',$productdetails->category_id)->with('merch_produt')->get();
        $productList = DB::table('merchandise_products AS m')
        ->leftJoin('products AS p', 'm.product_id', '=', 'p.id')
        ->leftJoin('merchandise_product_images AS i', 'm.id', '=', 'i.merch_product_id')
        ->where('p.category_id',$productdetails->category_id)
        ->where('m.status','1')
        ->where('m.deleted_at',null)
        ->take(3)
        ->get();
        $user_name = User::where('id',$merchproduct->artist_id)->first();
        $product_review = Review::where('product_id',$merchproduct->id)->get();
        $product_varient = Product_variant::where('product_id',$merchproduct->product_id)->get();
        
        foreach($product_varient as $value){
            $name =$value->attributes;
        }
        $variants = explode(",",$name);  
   	    $print_type = Print_types::where('status',1)->get();
        
    	//dd($print_type);
             
    	
        if(count($product_review)!=0){
            foreach ($product_review as $key => $value) {
                  $review_rating=$review_rating+$value->product_rating;
                  $total_review += $value->product_rating;
           }
           $review_point=$total_review/count($product_review);
           $review_average = round($total_review/count($product_review), 0);
       }
       else{
              $review_point=0;
              $review_average=0;
       }
      

    	
        $theme = DB::table("artist_themes")->where('user_id',$merchproduct->artist_id)->where('status',1)->first();

        return view('front/productdetail',compact('print_type','review_point','variants','merchproduct','productdetails','productList','merch_product','get_product','product_varient','user_name','theme','product_review','total_review','review_average'));
    }

    public function merch_cat()
    {
        $category = Categories::whereNull('deleted_at')->where('parent_id',0)->get();
        return view('front/merch_category',compact('category'));
    }

    public function merch_subcat($id)
    {
        $subcat = Categories::whereNull('deleted_at')->where('parent_id',$id)->get();
        $category = Categories::whereNull('deleted_at')->where('id',$id)->first();
        // dd($subcat);
        $get_cat = Categories::whereNull('deleted_at')->get();
        // dd($get_cat);
        if(count($subcat) > 0){
            return view('front/merch_sub_category',compact('subcat'));
        }
        else{

            $product = MerchandiseProductImages::with(['merch_image','ProductDetails.ProductCategory']);
            if($category){
                $product = $product->whereHas('ProductDetails.ProductCategory', function($q) use($category){
                $q->where('category_name',$category->category_name);
            });
            }
            $product = $product->paginate(6);
// dd($product);
            $product_fill = MerchandiseProductImages::with(['merch_image','ProductDetails.ProductCategory']);
                $product_fill = $product_fill->whereHas('ProductDetails.ProductCategory',function($q) use($category){
                $q->where('category_name',$category->category_name);   
            });

            $product_fill = $product->first();
            // dd($product_fill);
            $user = User::where('type',1)->get();
            $product_name = MerchandiseProduct::where('deleted_at',null)->get();
            $collection = collect($product_name);
            $unique_data = $collection->unique('merchandise_product_name')->values()->all();
        $product_data = DB::table('products')
                ->select('*')
                ->join('product_images', 'product_images.product_id', '=', 'products.id')
                ->where('products.category_id', $id)
                ->paginate(10);
            return view('front/product_list',compact('product','unique_data','product_name','product_fill','user','get_cat', 'product_data'));
        }
    }

    public function search()
    {
        $q = Input::get ( 'search' );
        $Products_check_box = Input::get ( 'drone' );
        $product = Product::where('product_name','LIKE','%'.$q.'%')->first();
        //dd($user);
        $x = 0;
        if($Products_check_box){
            $x = 1;
            $user = Product::where('product_name','LIKE','%'.$q.'%')->first();
            $product = MerchandiseProductImages::with(['merch_image','ProductDetails.ProductCategory']);
            $product = $product->whereHas('merch_image',function($q) use($user){
                $q->where('product_id',$user->id);
            });
        }
        if($product)
        {
            $product = $product->paginate(6);   
        }
        
        $get_cat = Categories::where('parent_id',0)->whereNull('deleted_at')->get();
        $user = User::where('type',1)->get();
        $product_name = MerchandiseProduct::where('deleted_at',null)->get(); 
        //dd($x);   
        return view('front/merch_prod_list',compact('product','product_name','get_cat','user','x'));
    }

	public function print_type_add(Request $request)
    {
    
     	  $print_type= array();
      	  $print_price= array();
      	   $detail = Product::where('id',$request->product_id)->first();
   		 if($request->status == 0)
   		 {
      	  if($detail->approved_additional_type){

      	  $print_type= unserialize($detail->approved_additional_type);
      	  $print_price= unserialize($detail->approved_additional_price);

     	   array_push($print_type,$request->type);
     	   array_push($print_price,$request->price);
       	 }
       	 else
       	 {
            $print_type[] = $request->type;
            $print_price[] = $request->price;    
      	  }

        $product_detail = Product::find($request->product_id);
        $product_detail->approved_additional_type = serialize($print_type);
        $product_detail->approved_additional_price = serialize($print_price);
        $product_detail->save();
       return response()->json(['status' => 'success','message'=>'Value inserted']); 
    	}
   	 else
    	{
    		
     
          $print_type= unserialize($detail->approved_additional_type);
      	  $print_price= unserialize($detail->approved_additional_price);
foreach (array_keys($print_type, $request->type, true) as $key) {
    unset($print_type[$key]);
	unset($print_price[$key]);
}
     	if(count($print_type) > 0)
        {
        $product_detail = Product::find($request->product_id);
        $product_detail->approved_additional_type = serialize($print_type);
        $product_detail->approved_additional_price = serialize($print_price);
        $product_detail->save();
        }
        else
        {
        $product_detail = Product::find($request->product_id);
        $product_detail->approved_additional_type = '';
        $product_detail->approved_additional_price = '';
        $product_detail->save();     
        }
     
     	return response()->json(['status' => 'success','message'=>'Value Updated']);
    	}
  
    }


public function image_display(Request $request)
    {
        if ($request->has('product_name')) {
            $destinationPath = public_path('portal/img/product');
        }        
        else
        {
            $destinationPath = public_path('portal/img/cropimages');
        }
        $file = $request->promotional_image;
        $array_array = $request->coords;
        $ch = str_replace("px","",$array_array);  
        $array = explode(',', $ch);
        $img_r = imagecreatefromjpeg($request->promotional_image);
        $dst_r = ImageCreateTrueColor( $array[2], $array[3] );

        $get_filename = $this->cropImage($request->promotional_image, $array[2], $array[3], $array[0], $array[1], $destinationPath);

        //return "<img src=". asset("portal/img/cropimages/".$get_filename).">";
        if ($request->has('product_name')) {
           return response()->json([
            'status' => 'success',
            'img_src' => asset("portal/img/product/".$get_filename),
            'get_filename'=>$get_filename,
            'count' => $request->count,
            'message'=>'Value inserted'
            ]); 
        }        
        else
        {
           return response()->json([
            'status' => 'success',
            'img_src' => asset("portal/img/cropimages/".$get_filename),
            'get_filename'=>$get_filename,
            'count' => $request->count,
            'message'=>'Value inserted'
            ]); 
        }
  

    }
    public function cropImage($file, $w, $h, $x, $y, $destinationPath)
    {
        $filename = rand() . '.' . $file->getClientOriginalExtension();
        $img = Image::make($file->getRealPath());
        $org_img = Image::make($file->getRealPath());
        
        $thumbPath = public_path('portal/img/thumbimages'); 
        if(!File::isDirectory($destinationPath)){
        File::makeDirectory($destinationPath, 0777, true, true);
        } 
        if(!File::isDirectory($thumbPath)){
        File::makeDirectory($thumbPath, 0777, true, true);
        }
        // Crop
        $img->crop($w, $h, $x, $y);
    	//$img->paintTransparentImage(($img->getImagePixelColor(0, 0), 0, 1200));
    	$canvas = $img;
    	
        $img->save($destinationPath.'/'. $filename );
        
 
        return $filename;
    }
}
