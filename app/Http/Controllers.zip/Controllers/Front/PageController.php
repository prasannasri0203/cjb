<?php

namespace App\Http\Controllers\Front;

use DB;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Featured_video;
use App\enquiry;
use Auth;
use App\OrderItem;
use App\MerchandiseProduct;
use App\MerchandiseProductImages;
use App\Cms;
use App\Notification;
use App\Notifications\MyEnquiryNotification;
use Mail;
use App\Banner;
use App\Faq;

class PageController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function productdetail()
    {
    	$data = DB::table("products")->whereNull('deleted_at')->orderBy('id', 'asc')->get(); 

        return view('front/productdetail', compact('data'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

    public function faq(Request $request)
    {
        //dd($request->search_text); 
        if($request->search_text)
        {
            $data = DB::table("faqs")
            ->whereNull('deleted_at')
            ->orderBy('id', 'asc')
            ->where('title', 'LIKE', '%'.$request->search_text.'%')
            ->orwhere('question', 'LIKE', '%'.$request->search_text.'%')
            ->orwhere('answer', 'LIKE', '%'.$request->search_text.'%')
            ->get();         
        }
        else
        {
            $data = DB::table("faqs")->whereNull('deleted_at')->orderBy('id', 'asc')->get();
        }
        $title = [];
        foreach ($data as $key => $value) {
            if (!in_array($value->title, $title))
            {
                $title[] = $value->title;
            }
        }
        $data=array_filter($title);
        //dd($data);
        return view('front/faq', compact('data'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function help()
    {
    	$data = DB::table("cms")->whereNull('deleted_at')->where('type', 'help')->orderBy('id', 'asc')->get(); 
        $banner = Banner::all()->where('status','2')->sortBy('id');
        $featured_video = Featured_video::where('type','Help')->get();

        return view('front/help', compact('data','featured_video','banner'));
    }

    public function currencySwitcher(Request $request){
        session()->put('my_currency', $request->id);
        return response()->json(['status' => 'success','message'=>'Currency Switched']);    

    }

    public function saveEnquiryDetails(Request $request)
    {       
        $validatedData = $request->validate([
            'name'          => 'required',
            'email'         => 'required|email|max:255',           
            'subject'       => 'required',
            'description'   => 'required',   
        ]);

        $content = [];
        
        $enquiry_details=new enquiry;
        $enquiry_details->name        =   $request->name;
        $enquiry_details->email       =   $request->email;
        $enquiry_details->subject     =   $request->subject;
        $enquiry_details->description =   $request->description;        
        $enquiry_details->save();

        $user = User::where('type', '0')->get();
        if($user){
            $details =[
                'id'  => $enquiry_details->id,
                'url' => 'admin/enquiry_edit/'.$enquiry_details->id,
            ];
            \Notification::send($user, new MyEnquiryNotification($details));
        }

    
        $content['name']  = $request->name;   
        $content['email'] = $request->email;
        $content['url']   = url("/admin/enquiry_edit/{$enquiry_details->id}");
		// dd($content);
        try{
            Mail::send('mails/enquiry_details', $content, function($message) use ($content) {
                $message->to('admin@example.com')->subject('Cool Jelly Bean : Enquiry ');
                $message->from($content['email']);
                // $message->setBody('test');
            });
            
        } catch(\Exception $e){
            return $e;
        }
        return redirect('help')->with('success', 'Kindly check your mail. We Will reach out to you soon.');
    }


     /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function ideas(Request $request)
    {
        $data=[];
        $ideas = DB::table("cms")->whereNull('deleted_at')
                                ->where('type','ideas')
                                ->first();
                                // dd($ideas);
        if($ideas){
        $data = DB::table("cms")->whereNull('deleted_at')
                                 ->where('type', 'ideas')
                                 ->where('id','!=',$ideas->id)
                                 ->orderBy('id', 'asc')
                                 ->paginate(6);
        }    
        return view('front/ideas', compact('data','ideas'));
    }

      /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function wishlist()
    {
        if(Auth::check()){
        $data = DB::table("wishlist")->whereNull('deleted_at')
                                     ->where('user_id', Auth::user()->id)
                                     ->where('like',1)
                                     ->orderBy('id', 'asc')
                                     ->paginate(3);
// dd($data);
        return view('front/wishlist', compact('data'));
        }
        else{
            return redirect('login')->with('failure', 'Invalid request..!!');
        }
    }

    public function wishlistadd(Request $request)
    {
        //dd($request->merch_product_id);
        if(Auth::check()){


            $product_details =  DB::table("merchandise_products")
                                     ->where('id',$request->merch_product_id)
                                     ->get();

            $product_variants =  DB::table("product_variants")
                                     ->where('id',$product_details[0]->product_variant_id)
                                     ->get();
                                     //dd($product_variants);
            if($product_variants[0]->quantites < 1)
            {
                    return response()->json([
                        'return_status' => 0,
                        'status' => true,
                        'quantites' => 0
                    ], 200);                
            }



        $data = DB::table("wishlist")->where('user_id', Auth::user()->id)
                                     ->whereNull('deleted_at')
                                     ->where('merch_product_id',$request->merch_product_id)
                                     ->get();
        if(count($data)>"0"){

                                  
   if($data[0]->like=="0" ){
         $like = "1";

   }else{
    $like = "0";
   }
        DB::table('wishlist')->delete($data[0]->id);
      return response()->json(['status' => 'success','message'=>'Removed from wishlist']);
} else{
    $like = "1";
}
   if(count($data)=="0"){
    DB::table('wishlist')->insert([
        ['merch_product_id' =>$request->merch_product_id, 'user_id' =>Auth::user()->id,'like'=>$like],
    ]);
   }else{
//dd(Auth::user()->id);
    // DB::table('wishlist')
    // ->whereNull('deleted_at')
    // ->where('user_id', Auth::user()->id)
    // ->where('merch_product_id', $request->merch_product_id)
    // ->update(['like'=>$like]);
    //dd($request->merch_product_id);
    
   }
        return response()->json($like);
    }
    else{
            $like = array('error');
            return response()->json($like);
     
    }
    }

    public function privacy(Request $request)
    {
        $data = DB::table("cms")->whereNull('deleted_at')->where('type', 'others')->where('slug','privacy-policy')->orderBy('id', 'asc')->get();         
        return view('front/praivacy',compact('data'));
    }

    public function privacySlug(Request $request,$slug)
    {
        $data = DB::table("cms")->whereNull('deleted_at')->where('type', 'others')->where('slug',$slug)->orderBy('id', 'asc')->get();         
        return view('front/praivacy',compact('data'));
    }

    public function terms(Request $request)
    {
        $data = DB::table("cms")->whereNull('deleted_at')->where('type', 'others')->where('slug','terms-and-conditions')->orderBy('id', 'asc')->get();         
        return view('front/terms',compact('data'));
    }

    
    public function termsSlug(Request $request,$slug)
    {
        $data = DB::table("cms")->whereNull('deleted_at')->where('type', 'others')->where('slug',$slug)->orderBy('id', 'asc')->get();         
        return view('front/terms',compact('data'));
    }

    public function shipping(Request $request)
    {
        $data = DB::table("cms")->whereNull('deleted_at')->where('type', 'others')->where('slug','shipping-and-returns')->orderBy('id', 'asc')->get(); 
    //dd($data);
        return view('front/shipping',compact('data'));
    }

    public function shippingSlug(Request $request,$slug)
    {
        $data = DB::table("cms")->whereNull('deleted_at')->where('type', 'others')->where('slug',$slug)->orderBy('id', 'asc')->get();         
        return view('front/terms',compact('data'));
    }
     /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function detailpage($id)
    {

    	$data = DB::table("cms")->whereNull('deleted_at')->where('id', $id)->first(); 
        $banner = Banner::all()->where('status','3')->sortBy('id');

        return view('front/detailpage', compact('data','banner'));
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function aboutMe($uname)
    {
        $userinfo = User::where("name",$uname)->first();
        // dd($userinfo);
        $id = $userinfo['id'];
        $user = User::whereIn('status', array(1))->whereNull('deleted_at')->find($id);
        // dd($user);
        if($user) {

            $data = DB::table("artist_gallery")->where('user_id', $id)->where('status', 1)->whereNull('deleted_at')->orderBy('id', 'asc')->limit(8)->get();
            $theme = DB:: table("artist_themes")->where('user_id',$id)->where('status',1)->first();
        	if(!$theme)
            {
            	$theme = DB:: table("artist_themes")->where('user_id',2)->where('status',1)->first();
            }
            $product_data = OrderItem::select(DB::raw('merchandise_products.product_id, COUNT(*) as count'))
                            ->join('merchandise_products','merchandise_products.id', '=','order_item.merchandise_product_id')
                            ->groupBy('merchandise_products.product_id')->orderBy('count','asc')->limit(3)->get();
        

            return view('front/about-me', compact('data', 'user','theme','product_data'));

        }

        return redirect('login')->with('failure', 'Invalid request..!!');
    }
	
	 public function createMerchendise(Request $request)
    {		
		$products = Product::with('product_category')->get();
        $tab = 'customise';
		

        return view('front/design-tool/marchandise-tab', compact('products', 'tab'));
    }
	
	

    public function customiseMerchendise(Request $request)
    {
        $prod = Product::where('id', $id)->first();
		$tab = 'customise';
		
		return view('front/design-tool/customise-tab', compact('prod', 'tab'));
    }

    public function search(){
        $q = Input::get ( 'q' );
        $user = Product::where('product_name','LIKE','%'.$q.'%')->first();
        
        if(count($user) > 0)
            return view('welcome')->withDetails($user)->withQuery ( $q );
            else return view ('welcome')->withMessage('No Details found. Try to search again !');
    }

}
