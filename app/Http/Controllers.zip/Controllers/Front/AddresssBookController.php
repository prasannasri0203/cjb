<?php

namespace App\Http\Controllers\Front;

use Auth;
use App\User;
use App\address_book;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class AddresssBookController extends Controller
{
    public function addressBook()
    {
        $country = DB::table('country')->get();
        return view('front/address_book',compact('country'));
    }

    public function store(Request $request)
    {
        // validate the data
        $this->validate($request, array(
            'fname' => 'required|regex:/^[a-zA-Z]+$/',
            'address1'  => 'required',
            // 'address2'  => 'required',
            'city_name' => 'required',
            'pscode'    => 'required',
            'country'   => 'required',
            'phone'     => 'nullable|integer'
        ));

        $user_id= Auth::user()->id;
        $user= User::where('id',$user_id)->first();
        $data = new address_book;
        $data->fname     = $request->fname;
        $data->sname     = $request->sname;
        $data->address1  = $request->address1;
        $data->address2  = $request->address2;
        $data->type      = $user->type;
        $data->user_id   = Auth::user()->id;
        $data->city_name = $request->city_name;
        $data->pscode    = $request->pscode;
        $data->country   = $request->country;
        $data->phone     = $request->phone;
        $data->primary   = $request->primary;
        $data->save();

        return redirect('address_book/list')->with('success',' Added successfully..!!');
    }

    public function edit($id)
    {
        $data = address_book::where('id',$id)->first();
        $country = DB::table('country')->get();
        return view('front/address_book_edit',compact('data','country'));
    }

    public function update(Request $request)
    {
        $this->validate($request, array(
            'fname' => 'required|string',
            'address1'  => 'required',
            // 'address2'  => 'required',
            'city_name' => 'required',
            'pscode'    => 'required',
            'country'   => 'required',
            'phone'     => 'nullable|integer'
        ));
        
        $data = address_book::find($request->id);
        // if($data != null) {

        $data->fname     = $request->input('fname');
        $data->sname     = $request->sname;
        $data->address1  = $request->input('address1');
        $data->address2  = $request->input('address2');
        $data->city_name = $request->input('city_name');
        $data->user_id   = Auth::user()->id;
        $data->pscode    = $request->input('pscode');
        $data->country   = $request->input('country');
        $data->phone     = $request->input('phone');
        $data->primary   = $request->input('primary');
        $data->update();
        
        
        return redirect('address_book/list')->with('success','Updated successfully..!!');
        // }

        // return redirect('address_book')->with('failure', 'Invalid request..!!');
    }

    public function list()
    {
    	$user_id= Auth::user()->id;
        $data = address_book::where('user_id',$user_id)->orderBy('primary','DESC')->get();
        return view('front/address_book_list',compact('data'));
    }

    public function delete(Request $request)
    {
        $applicant_id=$request->input('applicant_id');

        $data = address_book::where('id',$applicant_id)->first();
        $user = $data->delete();
        return redirect('address_book/list');
    }
}
