<?php

namespace App\Http\Controllers\Front;

use DB;
use App\User;
use App\OrderItem;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ArtistListController extends Controller
{
    public function create()
    {
        $artist_list = User::where('type',1)->whereIn('status', array(1))->whereNull('deleted_at')->paginate(5);
        $data = OrderItem::select(DB::raw('merchandise_products.artist_id, COUNT(*) as count'))
                            ->join('merchandise_products','merchandise_products.id', '=','order_item.merchandise_product_id')
                            ->groupBy('merchandise_products.artist_id')->orderBy('count','asc')->limit(3)->get();
                            // dd($data);
        return view('front/artist_list',compact('artist_list','data'));
    }

}
