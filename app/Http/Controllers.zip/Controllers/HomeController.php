<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\enquiry;
use DB;
use Notification;
use Illuminate\Support\Facades\Hash;
use App\Notifications\MyEnquiryNotification;
use App\Notifications\MyOrderNotification;
use App\Notifications\MyFaultAndReturnsNotification;
use App\Refferal;
use Mail;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    /**
     * Show the user's dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function dashboard()
    {
        $user_fields = User::where('id', Auth::user()->id)
            ->select('name', 'first_name', 'last_name', 'email', 'dob', 'contact_number', 'address_1', 'address_2', 'city', 'post_code', 'facebook_link', 'twitter_link', 'instagram_link', 'pinterest_link')
            ->first()->toArray();
        $not_fill_count = 0;
        foreach($user_fields as $key => $fields){
            if($fields == '' or $fields == null){
                $not_fill_count = $not_fill_count + 1;
            }
        }
        $total_fields = count($user_fields);
        $profile_percentage = 100 - ($not_fill_count / ($total_fields / 100));

        // dd($not_fill_count);
        if(Auth::user()->type == 1) {
            return view('front/dashboard-artist')->with([
                'profile_percentage' => number_format($profile_percentage, 1)
            ]);
        }
        $user_fields = User::where('id', Auth::user()->id)
        ->select('name', 'first_name', 'last_name', 'email', 'dob', 'contact_number', 'address_1', 'address_2', 'city', 'post_code' )
        ->first()->toArray();
    $not_fill_count = 0;
    foreach($user_fields as $key => $fields){
        if($fields == '' or $fields == null){
            $not_fill_count = $not_fill_count + 1;
        }
    }
    $total_fields = count($user_fields);
    $profile_percentage = 100 - ($not_fill_count / ($total_fields / 100));

        return view('front/dashboard-customer')->with([
            'profile_percentage' => number_format($profile_percentage, 1)
        ]);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function theme()
    {
        $data = DB::table('artist_themes')->where('user_id', Auth::user()->id)->first();
        if(!$data) {
            $data = collect();
            $data->banner_image = \URL::to('profile').'/artist-default-bg.png';
            $data->content_layer_colour = '#00afef';
            $data->cart_colour = '#ed1277';
            $data->font_family = 'Rubik-Light';
            $data->font_size = '15';
            $data->font_colour = '#ffffff';
        } else {
            $data->banner_image = \URL::to('profile').'/'.$data->banner_image;
        }

        return view('front/customise-theme', compact('data'));
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function editProfile()
    {
        return view('front/edit-profile');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function mediaGallery()
    {
        $data = DB::table("artist_gallery")->where('user_id', \Auth::user()->id)->where('status', 1)->whereNull('deleted_at')->orderBy('id', 'asc')->limit(100)->get(); 
// dd($data);
        return view('front/media-gallery', compact('data'));
    }

    public function editProfileUpdate(Request $request)
    {

        //dd($imageName);
        $this->validate($request, [
            'name' => 'required',
            'first_name' => 'required',
            'last_name' => 'required',
            // 'contact_number' => 'required',
            'email' => 'required|unique:users,email,'.\Auth::user()->id,
            'telephone' => 'required',
            'address_1' => 'required',
            'address_2' => 'required',
            'city' => 'required',
            'postcode' => 'required',
            'date_of_birth' => 'required',
            //'facebook' => 'url',
            //'twitter' => 'url',
            //'instagram' => 'url',
            //'pinterest' => 'url',
        ]);

        $data = User::whereIn('status', array(1))->find(\Auth::user()->id);

        if($data != null) {
            $data->name  = $request->input('name');
            $data->first_name  = $request->input('first_name');
            $data->last_name  = $request->input('last_name');
            $data->email  = $request->input('email');
            $data->contact_number  = $request->input('telephone');
            $data->address_1  = $request->input('address_1');
            $data->address_2  = $request->input('address_2');
            $data->city  = $request->input('city');
            $data->post_code  = $request->input('postcode');
            $data->dob  = $request->input('date_of_birth');
            $data->facebook_link  = $request->input('facebook');
            $data->twitter_link  = $request->input('twitter');
            $data->instagram_link  = $request->input('instagram');
            $data->pinterest_link  = $request->input('pinterest');
            $data->updated_at = date('Y-m-d H:i:s');
            if($request->artist_image)
            {
            $imageName = time().'.'.request()->artist_image->getClientOriginalExtension();
            $data->profile_image  = $imageName;
            request()->artist_image->move(public_path('profile'), $imageName);
            }
            $data->update();

            return redirect('edit-profile')->with('success', 'Updated successfully..!!');

        }

        return redirect('edit-profile')->with('failure', 'Invalid request..!!');
    }

    public function changepassword(Request $request)
    {
        $this->validate($request, [
            'password'        => 'required',
            ]);
        $data = User::whereIn('status', array(1))->find(\Auth::user()->id);
        if($data != null) {
            $data->password  = Hash::make($request->input('password'));
            $data->updated_at = date('Y-m-d H:i:s');
            $data->update();

            return redirect('edit-profile')->with('success', 'Updated successfully..!!');

        }

        return redirect('edit-profile')->with('failure', 'Invalid request..!!');

    }

    public function themeUpdate(Request $requesst)
    {
        $this->validate($request, [
            'banner_image' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
            'details_layer_colour' => 'required',
            'cart_colour' => 'required',
            'font_family' => 'required',
            'font_size' => 'required|integer|between:14,26',
            'font_colour' => 'required',
        ]);

        $data = DB::table('artist_themes')->where('user_id', Auth::user()->id)->first();

        if($request->hasfile('banner_image')) {
            $name= '0000'.Auth::user()->id.'-'.$request->banner_image->getClientOriginalName();
            $request->banner_image->move(public_path().'/profile/', $name);
            $filename = $name;
        }

        if($data) {
            if($request->hasfile('banner_image')) {
                $filename = $filename;
            } else {
                $filename = $data->banner_image;
            }

            $storeTheme = array('banner_image' => $filename,
                'content_layer_colour' => $request->details_layer_colour,
                'cart_colour' => $request->cart_colour,
                'font_family' => $request->font_family,
                'font_size' => $request->font_size,
                'font_colour' => $request->font_colour,
                'updated_at' => date('Y-m-d H:i:s')
                );
            DB::table('artist_themes')->where('user_id', Auth::user()->id)->update($storeTheme);

        } else {
            if($request->hasfile('banner_image')) {
                $filename = $filename;
            } else {
                $filename = 'artist-default-bg.png';
            }
            $storeTheme = array('user_id' => Auth::user()->id,
                'banner_image' => $filename,
                'content_layer_colour' => $request->details_layer_colour,
                'cart_colour' => $request->cart_colour,
                'font_family' => $request->font_family,
                'font_size' => $request->font_size,
                'font_colour' => $request->font_colour,
                'status' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            );
            DB::table('artist_themes')->insert($storeTheme);

        }
            
        return redirect('theme')->with('success', 'Updated successfully..!!');
    }

    public function mediaGalleryDestory($id)
    {
        $data = DB::table("artist_gallery")->where('user_id', \Auth::user()->id)->where('status', 1)->find($id); 

        if($data) {
            $dataUpdated = array('status' => -1,
            'deleted_at' => date('Y-m-d H:i:s')
            );
            \DB::table('artist_gallery')->where('id', $id)->update($dataUpdated);

            return redirect('media-gallery')->with('success', 'Deleted successfully..!!');

        }

        return redirect('media-gallery')->with('failure', 'Invalid request..!!');
    }

    public function createMerchendise(Request $request)
    {
		if ($request->ajax()) {

            $data = Product::where('products.status','0')->get();
            return Datatables::of($data)
                    ->addIndexColumn()
                    ->addColumn('date', function($row){
   
                        $date = date('d-m-Y', strtotime($row->updated_at));
                           return $date;
                            
                    })
                    ->addColumn('image', function($row){

                        if(@$row->product_image['front_side']) {
                            $path = asset('/portal/img/product/'.@$row->product_image['front_side']);
                        } else {
                            $path = asset('images/thanks.png');
                        }

   
                        $img = '<img src="'.$path.'" height="32px" width="32px" class="cms-image"/>';
                           
    
                            return $img;
                    })
                    ->rawColumns(['action', 'image'])
                    ->make(true);
        }
		
		$products = Product::with('product_category')->get();
        $tab = 'customise';
		

        return view('front/design-tool/marchandise-tab', compact('products', 'tab'));
    }
	
	

    public function customiseMerchendise(Request $request)
    {
        $prod = Product::where('id', $id)->first();
		$tab = 'customise';
		
		return view('front/design-tool/customise-tab', compact('prod', 'tab'));
    }

    public function mediaGalleryAdd(Request $request)
    {
        $this->validate($request, [
            'title' => 'required',
            // 'description' => 'required',
            'link' => 'required',
        ]);

        $data = array('user_id' => \Auth::user()->id,
            'title' => $request->title,
            // 'description' => $request->description,
            'link' => $request->link,
            'status' => 1,            
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );
        \DB::table('artist_gallery')->insert($data);

        return redirect('media-gallery')->with('success', 'Added successfully..!!');
    }

    public function editProfileAboutMe(Request $request)
    {
        $this->validate($request, [
            'about_me' => 'required',
            'about_stats' => 'required',
            'about_desc' => 'required',
        ]);

        $data = User::whereIn('status', array(1))->find(\Auth::user()->id);

        if($data != null) {
            $data->about_me  = $request->input('about_me');
            $data->about_stats  = $request->input('about_stats');
            $data->about_desc  = $request->input('about_desc');
            $data->updated_at =   \Carbon\Carbon::now();
            $data->update();

            return redirect('edit-profile')->with('success', 'Updated successfully..!!');

        }

        return redirect('edit-profile')->with('failure', 'Invalid request..!!');
    }

    public function ajaxUpload(Request $request)
    {
        // dd($request->all());
        try {
            // $location = public_path() . '/merchandise-img/';

            // if (!file_exists($location)) {
            //     mkdir($location, 0777, true);
            // }
            $name = time();

            $base64_image = $request->layer;

            if (preg_match('/^data:image\/(\w+);base64,/', $base64_image)) {
                $data = substr($base64_image, strpos($base64_image, ',') + 1);

                $data = base64_decode($data);
                // Storage::disk($location)->put($name, $data);
                // $data->move($location, $name);
                \Storage::disk('uploads')->put($name . '.png', $data);


                 $pdf = \App::make('dompdf.wrapper');
                 // $pdf = $pdf->setOptions(['isHtml5ParserEnabled' => true, 'isRemoteEnabled' => true]);
                 $img = "merchandise-img/".$name.".png";
                 $html = '
                 <html>
                     <head>
                         <style>
                             .center {
                                 text-align: center;
                             }
                             .center img {
                                 display: block;
                             }
                         </style>
                     </head>
                     <body>
                         <div class="center">
                             <img src="'.$base64_image.'" />
                         </div>
                     </body>
                 </html>
                 ';
                 $pdf->loadHTML($html);
                 \Storage::disk('uploads')->put($name . '.pdf', $pdf->output());



            }
            return "" . $name;
            // return "TEsted";
        } catch (Exception $e) {
            return $e;
        }

    }

    public function sendNotification(Request $request)
    {
        // $user = DB::table('enquiry')->first();
        $user = User::first();
        $details = [
            
            'id'  => 1,
            'url' => 'admin/enquiry_edit/1',
        ];
  
        Notification::send($user, new MyEnquiryNotification($details));
   
    }

    public function sendOrderNotification(Request $request)
    {
        // $user = DB::table('enquiry')->first();
        $user = User::first();
        $details = [
           
            'id' => 1
        ];
  
        Notification::send($user, new MyOrderNotification($details));
   
    }


    public function readEnquiryNotification($user_id)
    {
        $id = Auth::id();

        $user = User::find($id);

        $unread_enquiry_notifications = $user->unreadNotifications()->where('id',$user_id)->where('type','App\Notifications\MyEnquiryNotification')->first();
        $unread_enquiry_notifications->read_at = \carbon\carbon::now();
        $unread_enquiry_notifications->save();
        $data = $unread_enquiry_notifications->data['url'];
// dd($data);
        return redirect($data);
        
    }

    
    public function viewAll()
    {
        $user = Auth::user();

        $unread_enquiry_notifications  = $user->unreadNotifications()->where('type','App\Notifications\MyEnquiryNotification')
        ->update(['read_at' => \Carbon\Carbon::now()]);
        
        return redirect('admin/enquiry_list');

    }

    public function orderViewAll()
    {
        $user = Auth::user();

        $unread_order_notifications  = $user->unreadNotifications()->where('type','App\Notifications\MyOrderNotification')
        ->update(['read_at' => \Carbon\Carbon::now()]);
        
        return redirect('admin/order_index');
    }

    public function faultViewAll()
    {
        $user = Auth::user();

        $unread_fault_notifications  = $user->unreadNotifications()->where('type','App\Notifications\MyFaultAndReturnsNotification')
        ->update(['read_at' => \Carbon\Carbon::now()]);
        
        return redirect('admin/fault_list');

    }
    public function readFaultNotification($user_id)
    {
        $id = Auth::id();

        $user = User::find($id);

        $unread_fault_notifications = $user->unreadNotifications()->where('id',$user_id)->where('type','App\Notifications\MyFaultAndReturnsNotification')->first();
        $unread_fault_notifications->read_at = \carbon\carbon::now();
        $unread_fault_notifications->save();
        $data = $unread_fault_notifications->data['url'];
        // dd($data);
        return redirect($data);
    }

    public function readOrderNotification($user_id)
    {
        $id = Auth::id();

        $user = User::find($id);

        $unread_order_notifications = $user->unreadNotifications()->where('id',$user_id)->where('type','App\Notifications\MyOrderNotification')->first();
        $unread_order_notifications->read_at = \carbon\carbon::now();
        $unread_order_notifications->save();
        $data = $unread_order_notifications->data['url'];
        // dd($data);
        return redirect($data);
    }

    public function refferalcupon(Request $request)
    {
    //  dd($request->all());
        $refferal = new Refferal; 
        $refferal->user_id= Auth::user()->id;
        $user_id= Auth::user()->id;
        $refferal->user_email				=	$request->user_email;
        $refferal->description				=	$request->description;
        $refferal->status				=0;
        $refferal->save();	 
        $link = 'http://127.0.0.1:8000/signup?user_id='.$user_id;
        $params['user_email'] = $refferal['user_email'];	
        Mail::send('mails.refferal',  ['params' => $link,'name' => $request->user_email.' '.$request->description], function ($m) use ($params) {
                $m->from('711chitti@gmail.com', 'cooljellybean');
                $m->to($params['user_email']);
            });
            return redirect()->back()->with('success','We have e-mailed your regester link!');   
        }

  public function referral()
    {
        return view('front/referral');
    }
  
}
