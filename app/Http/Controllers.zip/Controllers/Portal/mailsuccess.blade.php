@extends('portal.app')

@section('title', 'Dashboard | ')

@section('header_css')
  
  <!-- end of plugin styles -->
@endsection

@section('content')
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">@lang('general.Dashboard')</h2>
            </div>
          </header>
          <section>   
            <div class="container-fluid">
              <div class="row">
                <div class="col-lg-12">
                    The mail has been send successfully....!!
                </div>
              </div>
            </div>
@endsection

@section('footer_script')
  <!-- end of plugin scripts -->
@endsection