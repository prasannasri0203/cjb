<?php

namespace App\Http\Controllers\Portal;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Imports\ShipmentDetailsImport;
use Maatwebsite\Excel\Facades\Excel;
use Carbon\Carbon;
use App\OrderStatusLabel;
use App\ShippingInfo;
use App\TrackingHistory;
use App\OrderItem;
use App\OrderDetails;
use App\MerchandiseProductImages;
use App\User;
use App\Supplier;
use App\Product;
use Auth;
use App\FaultReturn;
use App\FaultImage;
use App\FaultReturnHistory;
use App\Review;
use App\OrderCustomerAddressDetails;
use Illuminate\Support\Facades\Input;
use yajra\Datatables\Datatables;
use App\Categories;
use DB;
use App\CartDetails;

class OrderController extends Controller
{
   public function orderList()
   { 
    $resultData  = null;
    return view('portal/order/order_list',compact('resultData'));     
   }
   public function importShimentDetails(Request $request) {
       if($request->file('file')){
            $path = $request->file('file')->getRealPath();
            $import = new ShipmentDetailsImport;
            $data = Excel::import($import, $request->file('file'));    
            $resultData = $import->data;            
            return redirect()->route('admin.order_list')->with('resultData',$resultData);
       } else{
            return redirect()->route('admin.order_list')->with('error','No File Selected');
       }
   }

   public function shippingCreate(Request $request,$id){
     $order_item = OrderItem::where('order_id',$id)->first();
     $order_detail = OrderDetails::where('id',$order_item->id)->first();
     $status_list = OrderStatusLabel::get();
     $trackhistory=TrackingHistory::where('order_id',$id)->orderBy('id', 'ASC')->first(); 
     return view('portal/order/add_shipping_details',compact('status_list','order_item','order_detail','id','trackhistory'));
 }

 public function SaveShippingDetails(Request $request){
  //dd($request);
     $rules =[
         'order_id'          => 'required',
         'shipping_method'   => 'required',           
         'shipping_company'  => 'required',
         'tracking_num'      => 'required',           
         'shipping_date'     => 'required',
         'comments'          => 'required',
         'order_status_id'   => 'required'
     ];

     $customMessages = [
         'order_id.required'        => 'Order Id is required.',
         'shipping_method.required' => 'Shipping Method is required.',
         'shipping_company'         => 'Shipping Company is required',
         'tracking_num.required'    => 'Tracking Number is required.',
         'shipping_date.required'   => 'Shipping Date is required.',
         'comments.required'        => 'Comments is required.',
         'order_status_id.required' => 'Order Status is required.',

     ];
  
      $this->validate($request, $rules, $customMessages);

     $shippingInfo = new ShippingInfo;
          $shippingInfo->order_id     = $request->order_id;                                
          $shippingInfo->status       = $request->order_status_id;
          // $shippingInfo->created_at   = date('j F, Y');
          // $shippingInfo->updated_at   = date('j F, Y');
          $shippingInfo->save();
     $insertedId = $shippingInfo->id;

     if($insertedId){    
          $tracking = new TrackingHistory;
               $tracking->shipping_info_id	  = $insertedId;
               $tracking->shipping_method      = $request->shipping_method;
               $tracking->shipping_company     = $request->shipping_company;
               $tracking->tracking_num         = $request->tracking_num;
               $tracking->shipping_date        = new Carbon($request->shipping_date);
               $tracking->comments             = $request->comments;
               $tracking->order_status_id      = $request->order_status_id ? $request->order_status_id : 1;
               $tracking->order_id             = $request->order_prime_id;
               // $tracking->created_at           =   date('j F, Y');
               // $tracking->updated_at           =  date('j F, Y');
          $tracking->save();
     }
     return redirect()->route('admin.order_list')->with('success', 'Shipping Details Added successfully');

 }

 public function order_index(Request $request)
 {
      
     $cust = Input::get('cus_id');
     $sup = Input::get('sup_id');
     $art = Input::get('art_id');
	 $y ;
     $x=0;
     if($cust)
     {
      $request->customer = $cust;
     }
 
 
 //     $data = OrderItem::with(['CustomerDetails']);
 // dd($data = $data->get());
          
     $data = OrderItem::with(['orderDetails','get_images','supplierName','OrderDetails.customerDetails','get_images.ProductDetails','orderProducts.artistDetails','CustomerDetails']);
              if ($request->ajax()) {
               if($request->customer){
               		
                    $data = $data->whereHas('CustomerDetails', function($query) use ($request){
                         $query->where('id',$request->customer);
                    });                   
                   
                  $x=0;
                  //$data = DB::select("select  from `order_item` where exists (select  from `users`,`order_management` where `order_management`.`customer_id` = `users`.`id` and `users`.`id` = ".$request->customer.")  and `order_item`.`deleted_at` is null");

               }
               if($request->supplier){
                $x==0;
                    $data = $data->whereHas('supplierName', function($query) use ($request){
                         $query->where('id',$request->supplier);
                    });
               }
               if($request->order_ids){
                    $data = $data->whereHas('orderDetails', function($query) use($request){
                         $query->where('order_id',1);
                    });
                  $x=0;
                 //$data = DB::select("select exists (select * from `order_management`,`order_item` where `order_item`.`order_id` = `order_management`.`id` and `order_item`.`order_id` = ".$request->order_ids." and `order_management`.`deleted_at` is null)");

               }
               if($request->product){
                $x==0;
                    $data = $data->whereHas('get_images.ProductDetails', function($query) use ($request){
                         $query->where('product_name',$request->product);
                    });
               }
               if($request->artist){
                $x==0;
                    $data = $data->whereHas('orderProducts.artistDetails', function($query) use($request){
                         $query->where('id',$request->artist);
                    });
               }
               if($x==0)
               {
                  $data = $data->get();
               }
              
              //$status = DB::table('tracking_history ')->where('order_id',$row->id)->where('order_status_id',5);
               
          return Datatables::of($data)
          ->addIndexColumn()
          ->addColumn('action', function($row){
               $btn = '<a href="order_view/'.$row->id.'" class="btn btn-primary btn-sm">View</a>';
               // $btn = $btn.'<a href="order_edit/'.$row->id.'" class="btn btn-primary btn-sm">Edit</a>';
               $btn = $btn.' <a href="javascript:void(0)" data-toggle="modal" data-target="#myModal" data-id="'.$row->id.'"  onclick="setUserId('.$row->id.')" data-original-title="Delete" class="btn btn-danger btn-sm">Delete</a>';
          		$return_status = OrderDetails::where('id',$row->id)->get('return_status');
          	if(!$return_status[0]['return_status'] == 1)
                {
                //$status = DB::table('tracking_history ')->where('order_id',$row->id)->where('order_status_id',5);
               $btn = $btn.' <a href="javascript:void(0)" data-id="'.$row->id.'" id="button_id_'.$row->id.'"  onclick="enableReturn('.$row->order_id.')" class="btn btn-primary btn-sm">Enable return</a>';
          		return $btn;
                
                }
          		else
                {
         $btn = $btn.' <a href="javascript:void(0)" style="background-color : black" data-id="'.$row->id.'" id="button_id_'.$row->id.'"  onclick="enableReturn('.$row->order_id.')" class="btn btn-primary btn-sm">Disable return</a>';
                return $btn;
                }
          })
          ->addColumn('shipping_item_count', function($row){
            $x = OrderDetails::where('id', $row->id)->get('shipping_item_count');
            return $x[0]['shipping_item_count'];
          })
          ->addColumn('order_id', function($row){
            $x = OrderDetails::where('id', $row->id)->get('order_id');
            return $x[0]['order_id'];
          })
          ->addColumn('grand_total', function($row){
            $x = OrderDetails::where('id', $row->id)->get('grand_total');
            return $x[0]['grand_total'];
          })
          ->addColumn('status', function($row){
               if($row->status == 1){
                    return 'Pending';
               }
               else if($row->status == 2){
                    return 'Completed';
               }
               else if($row->status == 3){
                    return 'Cancelled';
               }
          })
          ->rawColumns(['action','status','order_id','shipping_item_count','grand_total'])
          ->make(true);
          }
          $customers = User::get();
          // dd($custmers);
          $supplier_name = Supplier::where('deleted_at', null)->get();
          $order_id = OrderDetails::where('deleted_at', null)->get();
          $product_name = Product::where('deleted_at',null)->get();
          $user = User::where('type',1)->where('deleted_at',null)->get();
          return view('portal/order/order_list',compact('customers','supplier_name','order_id','product_name','cust','sup','user','art'));

 }

 public function view_order($id)
 {
     //  dd($id);
     $order_details = null;
     if (Auth::check()) {
         $order_details = OrderDetails::where('id',$id)->with('orderItemDetails','orderItemDetails.orderProducts','orderItemDetails.orderProducts.merchProductImage','orderItemDetails.orderProducts.artistDetails','orderItemDetails.orderProducts.variantDetails','customerBillingAddress','customerDetails')->first();  

         $return_array = FaultReturn::where('order_id',$id)->pluck('product_id')->toArray();
         $order_product=OrderItem::where('id',$id)->first();
         $customer = User::where('id',$order_details->customer_id)->first();
         $review_data=Review::where('id',$id)
         ->orWhere('customer_id', $order_details->customer_id)
         ->first();
         $shippingInfo = TrackingHistory::where('order_id',$order_details->id)->get();
         //dd($shippingInfo);
         $shippingDate=TrackingHistory::where('order_id',$order_details->id)->where('order_status_id',2)->orderBy('id', 'ASC')->first(); 
         // $faults_returns = FaultReturn::where('order_id',$order_details->id)->get();
         // if($faults_returns)
         // {
         //    $faults_returns_history = FaultReturnHistory::where('fault_id',$faults_returns[0]['id'])->get();
         // }
         // dd($faults_returns_history);
     	$additional_charge = CartDetails::where('id',$order_details->cart_id)->first();

        $faults_returns = DB::table('faults_returns')
            ->select('*')
            ->join('faults_returns_history', 'faults_returns_history.fault_id', '=', 'faults_returns.id')
            ->join('products', 'products.id', '=', 'faults_returns.product_id')  
            ->where('faults_returns.order_id', $id)
            ->get();

          //dd($faults_returns);

     }
     return view('portal/order/order_view',compact('additional_charge','return_array','order_details','order_product','review_data','shippingInfo','customer','shippingDate','faults_returns'));
 }

 public function destroy(Request $request)
 {
     $id = $request->userId;
     OrderItem::find($id)->delete();
     return redirect()->route('admin.order_list')
     ->with('success','Order updated successfully');
 }

 public function edit($id)
 {
     $order_item = OrderItem::where('id',$id)->first();
     $order_detail = OrderDetails::where('id',$order_item->order_id)->first();
     // $supplier = Supplier::where('id',$order_item->supplier_id)->first();
     $order_id_data = $order_detail->order_id;
     $customer_detail = OrderCustomerAddressDetails::where('customer_id',$order_detail->customer_id)->first();
     return view('portal/order/order_edit',compact('order_item','order_detail','customer_detail','order_id_data'));
 }

 public function update(Request $request)
 {
     $rules =[
          'order_id'          => 'required',
          'sup_id'   => 'required',           
          'product_price'  => 'required',
          'tax_total'      => 'required',           
          'discount_total'     => 'required',
          'shipping_total'          => 'required',
          'grand_total'   => 'required',
          'status' => 'required'
      ];
 
      $customMessages = [
          'order_id.required'        => 'Order Id is required.',
          'sup_id.required' => 'supplier id is required.',
          'product_price.required'         => 'Product Price is required',
          'tax_total.required'    => 'Tax Total is required.',
          'discount_total.required'   => 'Discount Total is required.',
          'shipping_total.required'        => 'Shipping Total required.',
          'grand_total.required' => 'Grand Total is required.',
          'status' => 'status is required'
 
      ];
   
       $this->validate($request, $rules, $customMessages);

     $id = $request->id;
      //dd($request);
     $order_item['order_id'] = $request->order_id;
     $order_item['supplier_id'] = $request->sup_id;
     $order_item['product_price'] = $request->product_price;
     $order_item['status'] = $request->status;
     $order = OrderItem::find($id);
     $order->update($order_item);
     $order_detail['tax_total'] = $request->tax_total;
     $order_detail['discount_total'] = $request->discount_total;
     $order_detail['shipping_total'] = $request->shipping_total;
     $order_detail['grand_total'] = $request->grand_total;
     $orders = OrderDetails::where('order_id',$id);
     $orders->update($order_detail);
     return redirect()->route('admin.order_list')
     ->with('success','Order updated successfully');
 }

public function enable_return(Request $request)
 {
   $order_item['status'] = 1;

    $order = OrderDetails::find($request->id);
	$return_status = OrderDetails::where('id',$request->id)->get('return_status');
	
	if($return_status[0]['return_status'] == 0)
    {
    	$x =1;
    }
	else
	{
		$x =0;
	}
    //dd($order);
    $update = OrderDetails::where('id',$request->id)->update(['return_status'=>$x]);


    if($update)
    {
        return response()->json([
        	'return_status' => $x,
            'status' => true,
            'id' => $request->id
        ], 200);   
    }
    else
    {
        return response()->json([
       	 'return_status' => $x,
            'status' => false,
            'id' => ''
        ], 200);     
    }





 }

   
}
