<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Portal\DeliveryAndPackingController;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use App\Http\Controllers\Controller;
use yajra\Datatables\Datatables;

use Validator;
use App\DeliveryAndPacking;
use DB;


class DeliveryAndPackingController extends Controller
{
    public function index(Request $request)
    {
        // $data = DeliveryAndPacking::select(array('id', 'delivery_name', 'delivery_desc'))->get();
// dd($data);
        if ($request->ajax()) {
            $data = DeliveryAndPacking::select(array('id','type', 'delivery_name', 'delivery_value','delivery_desc'))->get();
            return Datatables::of($data)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
   
                        $btn = '<a href="delivery_packing_edit/'.$row->id.'" class="btn btn-primary btn-sm">Edit</a>';
                        $btn = $btn.' <a href="javascript:void(0)" data-toggle="modal" data-target="#myModal" data-id="'.$row->id.'"  onclick="setSetingId('.$row->id.')" data-original-title="Delete" class="btn btn-danger btn-sm">Delete</a>';
    
                            return $btn;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }
        return view('portal.delivery_packing_list');
    }

    public function create()
    {
        // return redirect('admin/delivery_packing_list')->with('failure','Invalid request.');
        
    	$data = DeliveryAndPacking::all();
    	// dd($data);
    	return view('portal.delivery_packing_share',compact('data'));
    }

    public function store(Request $request)
    {
        // return redirect('admin/delivery_packing_list')->with('failure','Invalid request.');

        $deliveryKey = preg_replace('/\s+/', '_', $request->delivery_key);

        
    	$this->validate($request, [
            'delivery_name' => 'required',
            'type' => 'required',
            'delivery_key' => 'required',
            'delivery_value' => 'required',
            'delivery_desc' => 'required',
        ]);
        $delivery =  DeliveryAndPacking::create([
            'delivery_name'=>$request->delivery_name,
            'type'=>$request->type,
            'delivery_key'=> strtolower($deliveryKey),
            'delivery_value'=>$request->delivery_value,
            'delivery_desc'=>$request->delivery_desc,
            'delivery_status'=>1,
        ]);
        return redirect()->route('admin.delivery_packing_list')
        ->with('success','deliverys created successfully');
    }
       
    // $delivery->select('delivery_name','delivery_key','delivery_value','delivery_desc');
        // $delivery->save();
       

    public function edit($id)
    {
        $data = DeliveryAndPacking::where('id', $id)->find($id);
        // dd($data);
        return view('portal.delivery_packing_create', compact('data'));
    }

    public function update(Request $request)
    {
        $deliveryKey = preg_replace('/\s+/', '_', $request->delivery_key);

    	$this->validate($request, [
    		'delivery_name' => 'required',
            'delivery_value' => 'required',
            'delivery_desc' => 'required',
        ]);
        $id = $request->delivery_id;
        // dd($id);
        $data = DeliveryAndPacking::find($id);
        // $delivery =  DeliveryAndPacking::Update([
         $data->delivery_name = $request->delivery_name;
         $data->type = $request->delivery_type;
         $data->delivery_value = $request->delivery_value;
         $data->delivery_desc = $request->delivery_desc;
        
    	$data->save();
    
        return redirect()->route('admin.delivery_packing_list')
        ->with('success','deliverys created successfully');
    }

    public function update_status(Request $request)
    {
        // return redirect('admin/delivery_packing_list')->with('failure','Invalid request.');

        $id = $request->userId;
       $data = DeliveryAndPacking::find($id)->delete();
      
    //  dd($data);
    return redirect()->route('admin.delivery_packing_list')
    ->with('success','User deleted successfully');
    }
}
